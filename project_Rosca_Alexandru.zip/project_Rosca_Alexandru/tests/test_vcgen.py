import subprocess
import sys

from veri import logic as L
from veri.driver import vcs
from veri.typecheck import INT

from .conftest import ROOT, src


def test_vcgen_does_not_depend_on_z3():
    code = "import sys, veri.driver; veri.driver.vcs('def f(a: int) -> int:\\n    return a\\n'); print('z3' in sys.modules)"
    out = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, check=True)
    assert out.stdout.strip() == "False"


def test_one_vc_per_ensures_without_loops(example):
    (fn,) = vcs(example("max2.veri"))
    assert [v.kind for v in fn.vcs] == ["ensures"] * 3
    assert [v.name for v in fn.vcs] == [
        "ensures result >= a", "ensures result >= b", "ensures result == a or result == b"]
    assert L.show(fn.vcs[0].formula) == "(a >= b ==> a >= a) and (not a >= b ==> b >= a)"
    assert [v.name for v in fn.vcs[0].variables] == ["a", "b"]


def test_vcs_carry_source_labels(example):
    (fn,) = vcs(example("max2.veri"))
    assert L.outline(fn.vcs[0].formula) == [
        "case 1:",
        "  assume if (line 7) is true: a >= b",
        "  prove  ensures (line 4): result >= a",
        "case 2:",
        "  assume if (line 7) is false: a >= b",
        "  prove  ensures (line 4): result >= a",
    ]


def test_three_vcs_per_loop(example):
    sum_to, count_to = vcs(example("sum.veri"))
    for fn in (sum_to, count_to):
        assert [v.kind for v in fn.vcs] == ["loop-entry", "loop-preserve", "loop-exit"]
    entry, preserve, exit_ = (L.show(v.formula) for v in count_to.vcs)
    # entry: invariant after `i = 0`, assuming `requires`
    assert entry == "n >= 0 ==> 0 <= n"
    # preservation: arbitrary loop state i@loop22 satisfying I && c, then wp(i = i + 1, I)
    assert preserve == "n >= 0 ==> ((i@loop22 <= n and i@loop22 < n) ==> i@loop22 + 1 <= n)"
    # exit: I && not c implies the postcondition with result := i
    assert exit_ == "n >= 0 ==> ((i@loop22 <= n and not i@loop22 < n) ==> i@loop22 == n)"
    assert L.Var("i@loop22", INT) in count_to.vcs[1].variables
    assert count_to.vcs[1].var_info["i@loop22"] == (
        "i", "at the start of an arbitrary iteration of the loop at line 22")


def test_requires_are_assumed():
    (fn,) = vcs(src("""
        def f(a: int) -> int:
            requires a > 0
            requires a < 10
            ensures result > 0
            return a
        """))
    assert L.show(fn.vcs[0].formula) == "(a > 0 and a < 10) ==> a > 0"


def test_assignment_substitutes_backwards():
    (fn,) = vcs(src("""
        def f(a: int) -> int:
            ensures result == a + 3
            x = a + 1
            x = x + 2
            return x
        """))
    assert L.show(fn.vcs[0].formula) == "a + 1 + 2 == a + 3"


def test_unmodified_variables_survive_the_loop():
    # k is not assigned in the loop, so its value is not havocked and need not be in the invariant.
    (fn,) = vcs(src("""
        def f(n: int) -> int:
            requires n >= 0
            ensures result == 5
            k = 5
            i = 0
            while i < n:
                invariant i <= n
                i = i + 1
            return k
        """))
    exit_vc = fn.vcs[-1]
    assert exit_vc.kind == "loop-exit"
    assert L.show(exit_vc.formula) == "n >= 0 ==> ((i@loop6 <= n and not i@loop6 < n) ==> 5 == 5)"


def test_short_circuit_guards_safety_checks():
    (fn,) = vcs(src("""
        def f(a: array, i: int) -> bool:
            return 0 <= i and i < len(a) and a[i] > 0
        """))
    (vc,) = fn.vcs
    assert vc.kind == "safety"
    # The bounds check of a[i] may assume the left operands of `and` were true.
    assert L.show(vc.formula) == "len(a) >= 0 ==> ((0 <= i and i < len(a)) ==> 0 <= i and i < len(a))"


def test_calls_check_pre_and_assume_post():
    fns = vcs(src("""
        def inc(x: int) -> int:
            requires x >= 0
            ensures result == x + 1
            return x + 1

        def twice(y: int) -> int:
            requires y >= 0
            ensures result == y + 2
            return inc(inc(y))
        """))
    twice = fns[1]
    assert [v.kind for v in twice.vcs] == ["ensures", "call-pre", "call-pre"]
    ens = twice.vcs[0]
    assert {v.name for v in ens.variables} == {"y", "inc@call9", "inc@call9_2"}
    assert ens.var_info["inc@call9"] == ("inc(y)", "value returned by the call at line 9")
    assert ens.var_info["inc@call9_2"] == ("inc(inc(y))", "value returned by the call at line 9")


def test_substitution_is_simultaneous_and_capture_avoiding():
    x, y = L.Var("x", INT), L.Var("y", INT)
    f = L.Cmp("==", x, y)
    assert L.show(L.substitute(f, {"x": y, "y": x})) == "y == x"
    # forall x :: x == y, with y := x must rename the bound x
    q = L.ForAll(x, L.Cmp("==", x, y))
    assert L.show(L.substitute(q, {"y": x})) == "forall x' :: x' == x"
