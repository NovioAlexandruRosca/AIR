"""Stalin sort: a correct version (compare with the last kept element) and a buggy one
(compare with the previous input element)."""

import random

import pytest

from .conftest import statuses, verify


def stalin_sort_keep_running_max(a):
    """Python reference of examples/stalin_sort_keep_running_max.veri."""
    out = []
    for x in a:
        if not out or x >= out[-1]:
            out.append(x)
    return out


def stalin_sort_compare_previous_input(a):
    """Python reference of examples/stalin_sort_compare_previous_input.veri."""
    out = []
    for i, x in enumerate(a):
        if not out or x >= a[i - 1]:
            out.append(x)
    return out


def satisfies_contract(a, result):
    """The ensures clauses of both .veri files, evaluated in Python."""
    return (len(result) <= len(a)
            and all(result[p - 1] <= result[p] for p in range(1, len(result)))
            and all(a[k] <= result[-1] for k in range(len(a)))
            and (not a or result[0] == a[0]))


def test_contract_matches_the_python_reference_implementations():
    """Sanity check of the specification itself on random inputs."""
    rng = random.Random(0)
    inputs = [[rng.randint(-5, 5) for _ in range(rng.randint(0, 8))] for _ in range(500)]
    assert all(satisfies_contract(a, stalin_sort_keep_running_max(a)) for a in inputs)
    assert stalin_sort_compare_previous_input([3, 1, 2]) == [3, 2]
    assert not satisfies_contract([3, 1, 2], [3, 2])


def test_stalin_sort_keep_running_max_verifies(example):
    results = verify(example("stalin_sort_keep_running_max.veri"))
    assert {r["status"] for r in results} == {"verified"}, results
    names = [r["vc"] for r in results]
    assert [n for n in names if n.startswith("loop")] == [
        "loop at line 20: invariant holds on entry",
        "loop at line 20: invariant is preserved by the body",
        "loop at line 20: invariant and not (i < len(a)) imply the rest",
    ]
    # Every array read in the code is proven in bounds.
    assert sorted(n for n in names if n.startswith("index")) == [
        "index in bounds: a[i]", "index in bounds: a[i]", "index in bounds: a[i]",
        "index in bounds: out[len(out) - 1]",
    ]


def test_stalin_sort_compare_previous_input_breaks_sortedness(example):
    results = verify(example("stalin_sort_compare_previous_input.veri"))
    st = statuses(results)
    assert st.pop("loop at line 16: invariant is preserved by the body") == "failed"
    assert set(st.values()) == {"verified"}  # entry, exit and all bounds checks still hold

    (failed,) = [r for r in results if r["status"] == "failed"]
    cex = failed["counterexample"]
    a, i, out = cex["a"], cex["i@loop16"], cex["out@loop16"]
    assert isinstance(a, list) and "..." not in a, "small-model search should give a short array"
    # The counterexample is a loop state satisfying the invariant and the loop condition...
    assert 0 <= i < len(a) and len(out) <= i
    assert all(out[p - 1] <= out[p] for p in range(1, len(out)))
    # ...from which one execution of the buggy body produces an unsorted output.
    if not out or a[i] >= a[i - 1]:
        out = out + [a[i]]
    assert any(out[p - 1] > out[p] for p in range(1, len(out)))


@pytest.mark.parametrize("a", [[3, 1, 2], [5, 1, 1], [2, 0, 1, 3]])
def test_buggy_variant_really_misbehaves_on_concrete_inputs(a):
    assert not satisfies_contract(a, stalin_sort_compare_previous_input(a))
    assert satisfies_contract(a, stalin_sort_keep_running_max(a))
