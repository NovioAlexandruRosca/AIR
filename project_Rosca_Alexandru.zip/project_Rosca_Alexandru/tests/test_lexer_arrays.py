import pytest

from veri.errors import LexError
from veri.lexer import tokenize


def test_range_and_brackets():
    toks = tokenize("forall k in 0..len(a): a[k] >= 0\n")
    assert [t.kind for t in toks] == [
        "forall", "NAME", "in", "INT", "..", "NAME", "(", "NAME", ")", ":",
        "NAME", "[", "NAME", "]", ">=", "INT", "NEWLINE", "EOF"]


def test_newlines_inside_brackets_are_ignored():
    toks = tokenize("x = [1,\n     2]\n")
    assert [t.kind for t in toks] == ["NAME", "=", "[", "INT", ",", "INT", "]", "NEWLINE", "EOF"]


def test_unclosed_bracket_points_at_the_opening_bracket():
    with pytest.raises(LexError) as ei:
        tokenize("def f(a: array) -> int:\n    return a[0\n")
    assert (ei.value.line, ei.value.col) == (2, 13)
    assert "never closed" in ei.value.message
