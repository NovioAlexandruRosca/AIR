"""Backend emitting a standalone Python script that checks the VCs with z3.

The script consists of the checking runtime (`z3runtime.py`, embedded
verbatim), one `vcs_<function>()` per function that builds its VC trees
(`z3tree.py` format) from z3 expressions, and a `main` that checks them.
Run it with `--brief` for one line per VC, `--show-z3` to also print each
VC as given to z3, `--raw` to add z3's raw model.

Representation: `int` is z3 `Int`, `bool` is `Bool`, `array` is the z3
datatype `IntArray = mk_array(data: Array(Int, Int), length: Int)`.
"""

from __future__ import annotations

import ast
import keyword
import re
from pathlib import Path
from typing import Any

from .. import __version__
from .. import logic as L
from ..typecheck import ARRAY, BOOL, INT, Type
from ..vcgen import FunctionVCs
from .z3tree import Builder, TreeConverter

#: How a variable of each source type is declared. Adding a type = adding an entry here.
Z3_DECL: dict[Type, str] = {INT: "Int({name!r})", BOOL: "Bool({name!r})", ARRAY: "Const({name!r}, IntArray)"}

#: Term-level operations as code templates (arguments are code strings).
CODE_OPS = {
    "+": "({0} + {1})", "-": "({0} - {1})", "*": "({0} * {1})", "//": "py_div({0}, {1})", "%": "py_mod({0}, {1})",
    "<": "({0} < {1})", "<=": "({0} <= {1})", ">": "({0} > {1})", ">=": "({0} >= {1})",
    "==": "({0} == {1})", "!=": "({0} != {1})",
    "neg": "(-{0})", "not": "Not({0})", "implies": "Implies({0}, {1})", "iff": "({0} == {1})",
    "ite": "If({0}, {1}, {2})", "forall": "ForAll([{0}], {1})", "exists": "Exists([{0}], {1})",
    "empty": "EMPTY_ARRAY", "len": "IntArray.length({0})", "select": "Select(IntArray.data({0}), {1})",
    "store": "array_store({0}, {1}, {2})", "append": "array_append({0}, {1})",
}

RUNTIME_MARKER = "# ---- embedded in generated scripts from here on ----"


def runtime_source() -> str:
    """The checking runtime (z3runtime.py) from its marker line on, embedded verbatim in every script."""
    text = Path(__file__).with_name("z3runtime.py").read_text(encoding="utf-8")
    return text[text.index(RUNTIME_MARKER) + len(RUNTIME_MARKER):].strip("\n") + "\n"


def _top_level_names(source: str) -> set[str]:
    names: set[str] = set()
    for node in ast.parse(source).body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names |= {a.asname or a.name.split(".")[0] for a in node.names}
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            names |= {t.id for t in node.targets if isinstance(t, ast.Name)}
    return names


# Names the generated module defines itself; source variables must not shadow them.
RESERVED = frozenset(_top_level_names(runtime_source()) | {"FUNCTIONS", "print", "str", "len", "int", "list",
                                                         "dict", "range", "sorted", "min", "max", "abs"})


class CodeBuilder(Builder):
    """Builds VC trees as Python source text; collects the z3 constants to declare."""

    def __init__(self) -> None:
        self.idents: dict[tuple[str, Type], str] = {}
        self.used: set[str] = set()

    def var(self, v: L.Var) -> str:
        key = (v.name, v.type)
        if key not in self.idents:
            ident = v.name
            if not ident.isidentifier() or keyword.iskeyword(ident) or ident in RESERVED or ident.startswith("_"):
                ident = "v_" + re.sub(r"\W", "_", v.name)
            cand, k = ident, 2
            while cand in self.used or cand in RESERVED:
                cand, k = f"{ident}_{k}", k + 1
            self.used.add(cand)
            self.idents[key] = cand
        return self.idents[key]

    def declarations(self) -> list[str]:
        return [f"{ident} = {Z3_DECL[t].format(name=name)}" for (name, t), ident in self.idents.items()]

    def const(self, value: int) -> str:
        return f"IntVal({value})"

    def boollit(self, value: bool) -> str:
        return f"BoolVal({value})"

    def apply(self, op: str, *args: Any) -> str:
        if op == "and":
            return "And(" + ", ".join(args) + ")"
        if op == "or":
            return "Or(" + ", ".join(args) + ")"
        return CODE_OPS[op].format(*args)

    def node(self, kind: str, text: str, *parts: Any) -> str:
        if kind == "label":
            label_kind, orig, env = parts
            return f"({kind!r}, {text!r}, {label_kind!r}, {orig}, {env})"
        if kind == "cmp":
            op, lhs, rhs = parts
            return f"({kind!r}, {text!r}, {op!r}, {lhs}, {rhs})"
        return "(" + ", ".join([repr(kind), repr(text), *parts]) + ")"

    def seq(self, items: list[str]) -> str:
        return "[" + ", ".join(items) + "]"

    def env_entry(self, name: str, var: str, value: str) -> str:
        return f"({name!r}, {var}, {value})"


class Z3PyBackend:
    name = "z3py"
    file_extension = ".py"

    def __init__(self, timeout_ms: int = 10_000):
        self.timeout_ms = timeout_ms

    def emit_function(self, fn: FunctionVCs) -> list[str]:
        b = CodeBuilder()
        conv = TreeConverter(b)
        for p in fn.params:
            b.var(p)
        entries = []
        for vc in fn.vcs:
            tree = conv.tree(vc.formula)
            variables = "[" + ", ".join(f"({b.var(v)}, {vc.var_info[v.name][0]!r}, {vc.var_info[v.name][1]!r})"
                                        for v in vc.variables) + "]"
            entries.append((vc, tree, variables))

        out = [f"def vcs_{fn.name}():", f'    """Verification conditions of `{fn.name}` (line {fn.pos.line})."""']
        out.extend("    " + d for d in b.declarations())
        out.append("    return [")
        for vc, tree, variables in entries:
            out.append(f"        # [{vc.kind}] {vc.name}")
            for line in L.outline(vc.formula):
                out.append(f"        #   {line}")
            out.append(f"        ({vc.name!r}, {vc.pos.line},")
            out.append(f"         {tree},")
            out.append(f"         {variables}),")
        out.append("    ]")
        return out

    def emit(self, functions: list[FunctionVCs], source_name: str) -> str:
        out = [
            "#!/usr/bin/env python3",
            f'"""Verification conditions for {source_name}.',
            "",
            f"Generated by veri {__version__}; do not edit. Requires only z3-solver.",
            "Run with `python <this file> [--brief] [--show-z3] [--raw]`.",
            "Exit status: 0 = all VCs verified, 1 = some VC failed, 2 = some VC inconclusive.",
            '"""',
            "",
            "# ---- checking runtime (veri/backends/z3runtime.py) ----",
            runtime_source(),
            f"TIMEOUT_MS = {self.timeout_ms}",
            "",
            "# ---- verification conditions ----",
        ]
        for fn in functions:
            out.append("")
            out.extend(self.emit_function(fn))
            out.append("")
        out.append("")
        out.append("FUNCTIONS = [")
        for fn in functions:
            out.append(f"    ({fn.name!r}, {fn.pos.line}, vcs_{fn.name}),")
        out.append("]")
        out.append("")
        out.append("")
        out.append('if __name__ == "__main__":')
        out.append("    sys.exit(main(FUNCTIONS))")
        return "\n".join(out).rstrip() + "\n"
