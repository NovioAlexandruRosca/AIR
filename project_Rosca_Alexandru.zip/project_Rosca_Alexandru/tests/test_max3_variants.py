"""The two max3 variants: strict `>` guards (buggy on ties) vs. non-strict `>=` guards (correct)."""

from veri.driver import check_with_z3

from .conftest import statuses, verify

UPPER = "ensures result >= a and result >= b and result >= c"
ONE_OF = "ensures result == a or result == b or result == c"


def run_max3_strict_compare(a, b, c):
    """Python reference of examples/max3_strict_compare.veri."""
    if a > b and a > c:
        return a
    elif b > a and b > c:
        return b
    return c


def test_max3_strict_compare_fails_when_a_and_b_tie_for_maximum(example):
    results = verify(example("max3_strict_compare.veri"))
    assert statuses(results) == {UPPER: "failed", ONE_OF: "verified"}
    (r,) = [r for r in results if r["status"] == "failed"]
    cex = r["counterexample"]
    a, b, c = cex["a"], cex["b"], cex["c"]
    # The only way to break it: a and b tie for the maximum, so both strict guards are false.
    assert a == b > c
    # Running the program on the counterexample really returns a non-maximum.
    assert run_max3_strict_compare(a, b, c) == c < max(a, b, c)


def test_max3_strict_compare_explanation_names_the_failing_branch(example, capsys):
    check_with_z3(example("max3_strict_compare.veri"), verbose=True, details=True)
    out = capsys.readouterr().out
    assert "if (line 13) is false: a > b and a > c" in out
    assert "elif (line 15) is false: b > a and b > c" in out
    assert "ensures (line 11): result >= a and result >= b and result >= c" in out


def test_max3_nonstrict_compare_verifies_all_postconditions(example):
    results = verify(example("max3_nonstrict_compare.veri"))
    assert len(results) == 2
    assert {r["status"] for r in results} == {"verified"}, results
