"""IR -> "VC tree", shared by the in-process checker (z3api) and the script emitter (z3py).

A VC tree is a nested tuple that the runtime (`z3runtime.py`) both turns into
a z3 formula (`build`) and walks to explain a counterexample (`explain`):

    ("and", text, [children])        ("or", text, [children])
    ("not", text, child)             ("implies", text, hyp, concl)
    ("iff", text, left, right)       ("forall"/"exists", text, var, body)
    ("cmp", text, op, lhs, rhs)      ("atom", text, expr)
    ("label", text, kind, orig, env)    env = [(source name, source var, value), ...]

A label stands for `orig` with each source var replaced by its value.

The converter is written once against a `Builder`, which decides what terms
and nodes are: live z3 objects (z3api) or Python source text (z3py).
"""

from __future__ import annotations

from typing import Any

from .. import logic as L


class Builder:
    """What a tree is made of. Terms and nodes are opaque to the converter."""

    def var(self, v: L.Var) -> Any: ...
    def const(self, value: int) -> Any: ...
    def boollit(self, value: bool) -> Any: ...
    def apply(self, op: str, *args: Any) -> Any: ...  # term-level operation, see TERM_OPS
    def node(self, kind: str, text: str, *parts: Any) -> Any: ...
    def seq(self, items: list[Any]) -> Any: ...  # a list inside a node
    def env_entry(self, name: str, var: Any, value: Any) -> Any: ...


# IR term node -> operation name understood by both builders.
TERM_OPS = {L.Neg: "neg", L.Not: "not", L.ArrLen: "len", L.ArrSelect: "select", L.ArrStore: "store",
            L.ArrAppend: "append", L.Ite: "ite", L.Implies: "implies", L.Iff: "iff"}


class TreeConverter:
    def __init__(self, b: Builder):
        self.b = b

    # ---- terms (any sort) ------------------------------------------------

    def term(self, e: L.Expr) -> Any:
        b = self.b
        if isinstance(e, L.Label):
            return self.term(L.semantics(e))
        if isinstance(e, L.Const):
            return b.const(e.value)
        if isinstance(e, L.BoolLit):
            return b.boollit(e.value)
        if isinstance(e, L.Var):
            return b.var(e)
        if isinstance(e, L.ArrEmpty):
            return b.apply("empty")
        if isinstance(e, (L.Arith, L.Cmp)):
            return b.apply(e.op, self.term(e.left), self.term(e.right))
        if isinstance(e, L.And):
            return b.apply("and", *(self.term(a) for a in e.args))
        if isinstance(e, L.Or):
            return b.apply("or", *(self.term(a) for a in e.args))
        if isinstance(e, (L.ForAll, L.Exists)):
            kind = "forall" if isinstance(e, L.ForAll) else "exists"
            return b.apply(kind, b.var(e.var), self.term(e.body))
        if type(e) in TERM_OPS:
            return b.apply(TERM_OPS[type(e)], *(self.term(c) for c in L.children(e)))
        raise TypeError(e)

    # ---- formulas as trees -----------------------------------------------

    def tree(self, e: L.Expr, text: bool = False) -> Any:
        """`text`: attach readable text to every node (inside labels, where it is shown)."""
        b = self.b
        t = L.show(e) if text else ""
        if isinstance(e, L.Label):
            env = dict(e.env)
            entries = [b.env_entry(name, b.var(v), self.term(env.get(name, v)))
                       for name, v in L.free_vars(e.orig).items()]
            return b.node("label", e.text, e.kind, self.tree(e.orig, text=True), b.seq(entries))
        if isinstance(e, (L.And, L.Or)):
            kind = "and" if isinstance(e, L.And) else "or"
            return b.node(kind, t, b.seq([self.tree(a, text) for a in e.args]))
        if isinstance(e, L.Not):
            return b.node("not", t, self.tree(e.arg, text))
        if isinstance(e, L.Implies):
            return b.node("implies", t, self.tree(e.hyp, text), self.tree(e.concl, text))
        if isinstance(e, L.Iff):
            return b.node("iff", t, self.tree(e.left, text), self.tree(e.right, text))
        if isinstance(e, (L.ForAll, L.Exists)):
            kind = "forall" if isinstance(e, L.ForAll) else "exists"
            return b.node(kind, t, b.var(e.var), self.tree(e.body, text))
        if isinstance(e, L.Cmp):
            return b.node("cmp", L.show(e), e.op, self.term(e.left), self.term(e.right))
        return b.node("atom", L.show(e), self.term(e))
