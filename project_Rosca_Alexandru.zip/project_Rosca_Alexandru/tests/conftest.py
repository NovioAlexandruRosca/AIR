from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from veri.driver import compile_source, run_generated

ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = ROOT / "examples"


def src(text: str) -> str:
    """Dedent a test program; strip the leading newline of a triple-quoted string."""
    return textwrap.dedent(text).lstrip("\n")


def verify(source: str) -> list[dict]:
    return run_generated(compile_source(source, "<test>"), verbose=False)


def statuses(results: list[dict]) -> dict[str, str]:
    return {r["vc"]: r["status"] for r in results}


@pytest.fixture
def example():
    return lambda name: (EXAMPLES / name).read_text(encoding="utf-8")
