"""Command-line interface.

    veri compile FILE [-o OUT.py]   send the VCs to z3 now; explain every failure in source terms;
                                    with -o, also write a standalone verifier script
    veri verify  FILE               the same check, one line per VC
    veri vcs     FILE               print the generated VCs as assume/prove outlines
    veri check   FILE               parse and type-check only
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from . import logic as L
from .driver import check, check_with_z3, compile_source, vcs
from .errors import CompileError


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="veri", description="Verify veri programs with z3.")
    ap.add_argument("--version", action="version", version=f"veri {__version__}")
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("compile", help="check the VCs with z3 now and explain failures")
    p.add_argument("file", type=Path)
    p.add_argument("-o", "--output", type=Path, help="also write a standalone Python verifier script here")
    p.add_argument("--brief", action="store_true", help="one line per VC, no explanation of failures")
    p.add_argument("--show-z3", action="store_true", help="also print each VC as the z3 term sent to the solver")
    p.add_argument("--raw", action="store_true", help="also print z3's raw model for failed VCs")
    p.add_argument("--timeout", type=int, default=10_000, help="z3 timeout per VC in ms (default 10000)")

    p = sub.add_parser("verify", help="check the VCs with z3 now, one line per VC")
    p.add_argument("file", type=Path)
    p.add_argument("--details", action="store_true", help="explain failures (as compile does)")
    p.add_argument("--show-z3", action="store_true", help="also print each VC as the z3 term sent to the solver")
    p.add_argument("--raw", action="store_true", help="also print z3's raw model for failed VCs")
    p.add_argument("--timeout", type=int, default=10_000, help="z3 timeout per VC in ms (default 10000)")

    p = sub.add_parser("vcs", help="print the verification conditions as assume/prove outlines")
    p.add_argument("file", type=Path)

    p = sub.add_parser("check", help="parse and type-check only")
    p.add_argument("file", type=Path)

    args = ap.parse_args(argv)
    try:
        source = args.file.read_text(encoding="utf-8")
    except OSError as e:
        print(f"veri: cannot read {args.file}: {e.strerror}", file=sys.stderr)
        return 2

    try:
        if args.command == "check":
            typed = check(source)
            print(f"{args.file}: OK ({len(typed.functions)} function(s))")
            return 0
        if args.command == "vcs":
            for fn in vcs(source):
                print(f"function {fn.name} (line {fn.pos.line}): {len(fn.vcs)} VC(s)")
                for vc in fn.vcs:
                    print(f"  [{vc.kind}] {vc.name}")
                    for line in L.outline(vc.formula):
                        print("      " + line)
            return 0
        script = None
        if args.command == "compile" and args.output:
            script = compile_source(source, args.file.name, timeout_ms=args.timeout)
        details = not args.brief if args.command == "compile" else args.details
        results = check_with_z3(source, verbose=True, details=details, show_z3=args.show_z3, raw=args.raw,
                                timeout_ms=args.timeout)
    except CompileError as e:
        print(e.render(source, str(args.file)), file=sys.stderr)
        return 2

    from .backends.z3runtime import report

    status = report(results)
    if script is not None:
        args.output.write_text(script, encoding="utf-8")
        print(f"wrote standalone verifier {args.output} (run: python {args.output} [--brief] [--show-z3] [--raw])")
    return status
