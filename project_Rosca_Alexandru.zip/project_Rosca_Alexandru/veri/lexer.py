"""Stage 1: lexer.

Turns source text into a flat token list. The language is indentation based
(like Python), so the lexer also emits NEWLINE, INDENT and DEDENT tokens:

* blank lines and comment-only lines (`# ...`) are ignored;
* indentation must use spaces; a tab in leading whitespace is an error;
* inside parentheses and brackets, line breaks are ignored (implicit line joining).

`&&`, `||` and `!` are accepted as aliases of `and`, `or` and `not`.
"""

from __future__ import annotations

from dataclasses import dataclass

from .errors import LexError, Pos

KEYWORDS = frozenset(
    {
        "def", "return", "if", "elif", "else", "while",
        "requires", "ensures", "invariant", "decreases", "forall", "exists", "in",
        "and", "or", "not", "True", "False",
    }
)

# Longest operators first so that "<==>" wins over "<=" and ">=" over ">".
OPERATORS = (
    "<==>", "==>", "->", ">=", "<=", "==", "!=", "//", "..", "&&", "||",
    ">", "<", "=", "+", "-", "*", "%", "!", "(", ")", "[", "]", ":", ",",
)
ALIASES = {"&&": "and", "||": "or", "!": "not"}

# Characters we recognise only to report a targeted error.
UNSUPPORTED_OPS = {
    "/": "use '//' for integer division",
    "&": "use 'and' (or '&&')",
    "|": "use 'or' (or '||')",
}


@dataclass(frozen=True)
class Token:
    kind: str  # "NAME", "INT", "NEWLINE", "INDENT", "DEDENT", "EOF", or the keyword/operator text
    text: str
    pos: Pos

    @property
    def line(self) -> int:
        return self.pos.line

    @property
    def col(self) -> int:
        return self.pos.col

    def __repr__(self) -> str:
        return f"Token({self.kind!r}, {self.text!r}, {self.pos})"


def tokenize(source: str) -> list[Token]:
    tokens: list[Token] = []
    indents = [0]
    open_brackets: list[Pos] = []  # positions of unclosed ( and [
    lines = source.splitlines()

    for lineno, raw in enumerate(lines, start=1):
        i = 0
        n = len(raw)

        if not open_brackets:
            # Measure indentation of a new logical line.
            while i < n and raw[i] in " \t":
                if raw[i] == "\t":
                    raise LexError("tabs are not allowed in indentation; use spaces", Pos(lineno, i + 1))
                i += 1
            if i == n or raw[i] == "#":
                continue  # blank or comment-only line
            width = i
            if width > indents[-1]:
                indents.append(width)
                tokens.append(Token("INDENT", "", Pos(lineno, 1)))
            elif width < indents[-1]:
                while width < indents[-1]:
                    indents.pop()
                    tokens.append(Token("DEDENT", "", Pos(lineno, width + 1)))
                if width != indents[-1]:
                    raise LexError("unindent does not match any outer indentation level", Pos(lineno, width + 1))

        while i < n:
            ch = raw[i]
            if ch in " \t":
                i += 1
                continue
            if ch == "#":
                break
            pos = Pos(lineno, i + 1)
            if ch.isdigit():
                j = i
                while j < n and raw[j].isdigit():
                    j += 1
                if j < n and (raw[j].isalpha() or raw[j] == "_"):
                    raise LexError(f"invalid integer literal {raw[i:j + 1]!r}", pos)
                tokens.append(Token("INT", raw[i:j], pos))
                i = j
                continue
            if ch.isalpha() or ch == "_":
                j = i
                while j < n and (raw[j].isalnum() or raw[j] == "_"):
                    j += 1
                word = raw[i:j]
                tokens.append(Token(word if word in KEYWORDS else "NAME", word, pos))
                i = j
                continue
            for op in OPERATORS:
                if raw.startswith(op, i):
                    if op in ("(", "["):
                        open_brackets.append(pos)
                    elif op in (")", "]") and open_brackets:
                        open_brackets.pop()
                    tokens.append(Token(ALIASES.get(op, op), op, pos))
                    i += len(op)
                    break
            else:
                if ch in UNSUPPORTED_OPS:
                    raise LexError(f"'{ch}' is not an operator: {UNSUPPORTED_OPS[ch]}", pos)
                raise LexError(f"unexpected character {ch!r}", pos)

        if not open_brackets and tokens and tokens[-1].kind not in ("NEWLINE", "INDENT", "DEDENT"):
            tokens.append(Token("NEWLINE", "", Pos(lineno, n + 1)))

    if open_brackets:
        raise LexError("this bracket is never closed", open_brackets[-1])
    eof_line = len(lines) + 1
    if tokens and tokens[-1].kind not in ("NEWLINE", "DEDENT", "INDENT"):
        tokens.append(Token("NEWLINE", "", Pos(eof_line, 1)))
    while len(indents) > 1:
        indents.pop()
        tokens.append(Token("DEDENT", "", Pos(eof_line, 1)))
    tokens.append(Token("EOF", "", Pos(eof_line, 1)))
    return tokens
