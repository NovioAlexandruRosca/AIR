"""`veri compile` sends the VCs to z3 in-process and explains every failure in source terms."""

import subprocess
import sys

import pytest

from veri.driver import check_with_z3, compile_source, run_generated

from .conftest import EXAMPLES, ROOT, src

ALL_EXAMPLES = sorted(p.name for p in EXAMPLES.glob("*.veri"))


def run_cli(*args, cwd=ROOT):
    return subprocess.run([sys.executable, "-m", "veri", *map(str, args)], cwd=cwd, capture_output=True, text=True)


def explanation(source):
    (r,) = [r for r in check_with_z3(source, verbose=False, details=True) if r["status"] == "failed"]
    return "\n".join(r["explanation"])


def test_compile_checks_with_z3_and_writes_no_file_without_o(tmp_path):
    proc = run_cli("compile", EXAMPLES / "max3.veri", cwd=tmp_path)
    assert proc.returncode == 0, proc.stderr
    assert list(tmp_path.iterdir()) == []
    assert "unsat = the VC holds for all values (verified)" in proc.stdout
    assert proc.stdout.count("[verified]") == 4
    assert "total: 4 verified, 0 failed, 0 inconclusive of 4 VCs" in proc.stdout


def test_compile_explains_a_failure(tmp_path):
    proc = run_cli("compile", EXAMPLES / "max3_strict_compare.veri", "-o", tmp_path / "max3_new.py", "--show-z3",
                   "--raw")
    assert proc.returncode == 1
    out = proc.stdout
    assert "z3: Not(VC) is sat, so the VC can be violated" in out
    assert "a = 0, b = 0, c = -1" in out and "(parameter)" in out
    assert "assuming:" in out and "this does not hold:" in out
    assert "where result = -1, a = 0, b = 0, c = -1" in out
    assert "VC as given to z3" in out and "raw z3 model: [" in out
    assert "wrote standalone verifier" in out
    script = subprocess.run([sys.executable, str(tmp_path / "max3_new.py")], cwd=tmp_path,
                            capture_output=True, text=True)
    assert script.returncode == 1 and "this does not hold:" in script.stdout


def test_compile_brief():
    proc = run_cli("compile", EXAMPLES / "max2_buggy.veri", "--brief")
    assert proc.returncode == 1 and "assuming:" not in proc.stdout and "counterexample: a = " in proc.stdout


def test_explanation_of_a_broken_loop_invariant(example):
    text = explanation(example("stalin_sort_compare_previous_input.veri"))
    assert "(at the start of an arbitrary iteration of the loop at line 16)" in text
    assert "elif (line 26) is true: a[i] >= a[i - 1]" in text
    assert "invariant (line 20) again after the body: forall p in 1 .. len(out): out[p - 1] <= out[p]" in text
    assert "fails for p = " in text and "out[p - 1] <= out[p]   is   " in text


def test_explanation_of_a_failing_callee_precondition(example):
    results = check_with_z3(example("recursion_bugs.veri"), verbose=False, details=True)
    by_name = {r["vc"]: r for r in results}
    pre = "\n".join(by_name["precondition of sum_rec_skips_by_two holds for sum_rec_skips_by_two(n - 2)"]
                    ["explanation"])
    assert "n = 1" in pre
    assert "with the call's arguments n = -1" in pre
    assert "n >= 0   is   -1 >= 0   which is false" in pre


def test_recursion_bugs_fail_as_documented(example):
    results = check_with_z3(example("recursion_bugs.veri"), verbose=False)
    assert {r["vc"]: r["status"] for r in results} == {
        "ensures 2 * result == n * (n + 1)": "failed",
        "precondition of sum_rec_skips_by_two holds for sum_rec_skips_by_two(n - 2)": "failed",
        "termination: sum_rec_skips_by_two(n - 2) decreases the measure": "failed",
        "ensures result == 42": "verified",  # partial correctness alone would accept it...
        "termination: never_terminates(n) decreases the measure": "failed",  # ...termination does not
    }


def test_explanation_of_exists():
    text = explanation(src("""
        def f(a: array, x: int) -> bool:
            ensures result ==> exists k in 0 .. len(a): a[k] == x
            return True
        """))
    assert "no k in the range makes it true" in text


def test_explanation_of_or():
    text = explanation(src("""
        def f(x: int) -> int:
            ensures result > x or result < x
            return x
        """))
    assert "none of these holds:" in text
    assert "result > x   is   " in text and "result < x   is   " in text


@pytest.mark.parametrize("name", ALL_EXAMPLES)
def test_in_process_and_generated_script_agree(example, name):
    direct = check_with_z3(example(name), verbose=False)
    generated = run_generated(compile_source(example(name), name), verbose=False)
    strip = lambda rs: [(r["vc"], r["status"], r["check"]) for r in rs]  # noqa: E731
    assert strip(direct) == strip(generated)
    for r in direct:
        assert r["check"] == {"verified": "unsat", "failed": "sat", "unknown": "unknown"}[r["status"]]
        assert (r["model"] is not None) == (r["status"] == "failed")
