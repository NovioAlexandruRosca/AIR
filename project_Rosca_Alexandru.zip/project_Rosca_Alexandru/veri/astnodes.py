"""Stage 2 output: the abstract syntax tree.

Every node carries the source position of its first token. There is one
expression syntax for `int`, `bool` and `array` values; the type checker
decides where a `bool` is required (conditions, contracts).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Union

from .errors import Pos

# ---- expressions ---------------------------------------------------------


@dataclass
class IntLit:
    value: int
    pos: Pos


@dataclass
class BoolLit:
    value: bool
    pos: Pos


@dataclass
class Name:
    ident: str
    pos: Pos


@dataclass
class UnaryOp:
    op: str  # "-" or "not"
    operand: "Expr"
    pos: Pos


@dataclass
class BinOp:
    """Arithmetic (+ - * // %), comparison (< <= > >= == !=) or logic (and or ==> <==>)."""

    op: str
    left: "Expr"
    right: "Expr"
    pos: Pos


@dataclass
class Index:
    """`array[index]`"""

    array: "Expr"
    index: "Expr"
    pos: Pos


@dataclass
class Call:
    """A call to a builtin (len, append, abs, min, max) or to a user-defined function."""

    func: str
    args: list["Expr"]
    pos: Pos


@dataclass
class ArrayLit:
    """`[e1, e2, ...]`, possibly empty."""

    elems: list["Expr"]
    pos: Pos


@dataclass
class Quant:
    """`forall var in lo .. hi: body` / `exists var in lo .. hi: body` (var ranges over lo <= var < hi)."""

    kind: str  # "forall" or "exists"
    var: str
    lo: "Expr"
    hi: "Expr"
    body: "Expr"
    pos: Pos


Expr = Union[IntLit, BoolLit, Name, UnaryOp, BinOp, Index, Call, ArrayLit, Quant]

ARITH_OPS = ("+", "-", "*", "//", "%")
CMP_OPS = ("<", "<=", ">", ">=", "==", "!=")
LOGIC_OPS = ("and", "or", "==>", "<==>")

# ---- statements ----------------------------------------------------------


@dataclass
class Assign:
    target: str
    value: Expr
    pos: Pos


@dataclass
class AssignIndex:
    """`target[index] = value`; arrays are values, so this rebinds `target` to an updated copy."""

    target: str
    index: Expr
    value: Expr
    pos: Pos


@dataclass
class Return:
    value: Expr
    pos: Pos


@dataclass
class If:
    cond: Expr
    then_body: list["Stmt"]
    else_body: list["Stmt"]  # empty when there is no else branch
    pos: Pos
    keyword: str = "if"  # "elif" when desugared from an elif chain


@dataclass
class While:
    cond: Expr
    invariants: list[Expr]
    body: list["Stmt"]
    pos: Pos


Stmt = Union[Assign, AssignIndex, Return, If, While]

# ---- declarations --------------------------------------------------------


@dataclass
class TypeRef:
    name: str
    pos: Pos


@dataclass
class Param:
    name: str
    type: TypeRef
    pos: Pos


@dataclass
class Function:
    name: str
    params: list[Param]
    return_type: TypeRef
    requires: list[Expr]
    ensures: list[Expr]
    body: list[Stmt]
    pos: Pos
    decreases: Optional[Expr] = None


@dataclass
class Program:
    functions: list[Function] = field(default_factory=list)


# ---- pretty printing (used for VC labels and diagnostics) ----------------

# Binding strength, loosest first. Quantifiers extend as far right as possible.
PREC = {"quant": 0, "<==>": 1, "==>": 2, "or": 3, "and": 4, "not": 5, "cmp": 6,
        "+": 7, "-": 7, "*": 8, "//": 8, "%": 8, "neg": 9, "postfix": 10}


def _prec(op: str) -> int:
    return PREC["cmp"] if op in CMP_OPS else PREC[op]


def show_expr(e: Expr, parent: int = 0) -> str:
    """Render an expression with the minimum parentheses needed to read it back the same way."""
    if isinstance(e, IntLit):
        return str(e.value)
    if isinstance(e, BoolLit):
        return "True" if e.value else "False"
    if isinstance(e, Name):
        return e.ident
    if isinstance(e, UnaryOp):
        if e.op == "-":
            s, p = f"-{show_expr(e.operand, PREC['neg'])}", PREC["neg"]
        else:
            s, p = f"not {show_expr(e.operand, PREC['not'])}", PREC["not"]
        return f"({s})" if p < parent else s
    if isinstance(e, Index):
        return f"{show_expr(e.array, PREC['postfix'])}[{show_expr(e.index)}]"
    if isinstance(e, Call):
        return f"{e.func}({', '.join(show_expr(a) for a in e.args)})"
    if isinstance(e, ArrayLit):
        return f"[{', '.join(show_expr(a) for a in e.elems)}]"
    if isinstance(e, Quant):
        s = f"{e.kind} {e.var} in {show_expr(e.lo)} .. {show_expr(e.hi)}: {show_expr(e.body)}"
        return f"({s})" if parent > 0 else s
    if isinstance(e, BinOp):
        p = _prec(e.op)
        if e.op == "==>":  # right-associative
            s = f"{show_expr(e.left, p + 1)} ==> {show_expr(e.right, p)}"
        elif e.op in CMP_OPS:  # non-associative
            s = f"{show_expr(e.left, p + 1)} {e.op} {show_expr(e.right, p + 1)}"
        else:  # left-associative
            s = f"{show_expr(e.left, p)} {e.op} {show_expr(e.right, p + 1)}"
        return f"({s})" if p < parent else s
    raise TypeError(f"not an expression: {e!r}")


# Kept for callers that think of contracts as "conditions".
show_cond = show_expr


def expr_pos(e: Expr) -> Pos:
    return e.pos
