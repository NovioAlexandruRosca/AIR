"""End-to-end: compile to Python, run the z3 checks, inspect the results."""

import subprocess
import sys

import pytest

from veri.driver import compile_source, run_generated

from .conftest import EXAMPLES, ROOT, src, statuses, verify


@pytest.mark.parametrize("name", ["max2.veri", "max3.veri", "sum.veri", "recursion.veri", "operators.veri"])
def test_correct_examples_verify(example, name):
    results = verify(example(name))
    assert results
    assert {r["status"] for r in results} == {"verified"}, results


def test_buggy_max2_reports_counterexample(example):
    results = verify(example("max2_buggy.veri"))
    by_vc = {r["vc"]: r for r in results}
    assert by_vc["ensures result == a or result == b"]["status"] == "verified"

    for clause in ("ensures result >= a", "ensures result >= b"):
        r = by_vc[clause]
        assert r["status"] == "failed"
        cex = r["counterexample"]
        assert set(cex) == {"a", "b"} and all(isinstance(v, int) for v in cex.values())
        # The counterexample really breaks the clause when the buggy body is executed.
        a, b = cex["a"], cex["b"]
        result = a if a <= b else b
        assert not (result >= a and result >= b)
        assert not (result >= (a if clause.endswith("a") else b))


def test_generated_file_is_standalone_and_runnable(tmp_path, example):
    for name, expected_exit in (("max2.veri", 0), ("max2_buggy.veri", 1)):
        out = tmp_path / name.replace(".veri", ".py")
        out.write_text(compile_source(example(name), name), encoding="utf-8")
        proc = subprocess.run([sys.executable, str(out)], cwd=tmp_path, capture_output=True, text=True)
        assert proc.returncode == expected_exit, proc.stdout + proc.stderr
        assert "function max2 (line" in proc.stdout
        if expected_exit:
            assert "[FAILED]" in proc.stdout and "counterexample:" in proc.stdout
            assert "this does not hold:" in proc.stdout
            assert "summary: 1 verified, 2 failed, 0 inconclusive of 3 VCs -> FAILED" in proc.stdout
        else:
            assert "summary: 3 verified, 0 failed, 0 inconclusive of 3 VCs -> VERIFIED" in proc.stdout


def test_cli_compile_and_verify(tmp_path):
    out = tmp_path / "sum.py"
    proc = subprocess.run([sys.executable, "-m", "veri", "compile", str(EXAMPLES / "sum.veri"), "-o", str(out)],
                          cwd=ROOT, capture_output=True, text=True)
    assert proc.returncode == 0 and out.exists(), proc.stderr
    assert "total: 6 verified, 0 failed, 0 inconclusive of 6 VCs" in proc.stdout
    proc = subprocess.run([sys.executable, str(out)], cwd=tmp_path, capture_output=True, text=True)
    assert proc.returncode == 0 and "total: 6 verified" in proc.stdout, proc.stdout + proc.stderr
    proc = subprocess.run([sys.executable, "-m", "veri", "verify", str(EXAMPLES / "max2_buggy.veri")],
                          cwd=ROOT, capture_output=True, text=True)
    assert proc.returncode == 1
    assert "total: 1 verified, 2 failed, 0 inconclusive of 3 VCs" in proc.stdout
    assert "this does not hold" not in proc.stdout  # verify is the compact form
    assert "counterexample: a = " in proc.stdout


def test_cli_reports_errors_with_position(tmp_path):
    bad = tmp_path / "bad.veri"
    bad.write_text("def f(a: int) -> int:\n    return a / 1\n", encoding="utf-8")
    proc = subprocess.run([sys.executable, "-m", "veri", "compile", str(bad)], cwd=ROOT, capture_output=True, text=True)
    assert proc.returncode == 2
    assert f"{bad}:2:14: syntax error: '/' is not an operator: use '//' for integer division" in proc.stderr


def test_wrong_invariant_fails_on_entry():
    results = verify(src("""
        def count_to(n: int) -> int:
            requires n >= 0
            ensures result == n
            i = 0
            while i < n:
                invariant i < n
                i = i + 1
            return i
        """))
    by_kind = {r["vc"].split(": ", 1)[1]: r for r in results}
    entry = by_kind["invariant holds on entry"]
    assert entry["status"] == "failed" and entry["counterexample"] == {"n": 0}
    assert by_kind["invariant is preserved by the body"]["status"] == "failed"


def test_too_weak_invariant_fails_on_exit():
    results = verify(src("""
        def count_to(n: int) -> int:
            requires n >= 0
            ensures result == n
            i = 0
            while i < n:
                invariant i >= 0
                i = i + 1
            return i
        """))
    assert [r["status"] for r in results] == ["verified", "verified", "failed"]
    cex = results[2]["counterexample"]
    assert cex["i@loop5"] > cex["n"]  # the loop could have overshot n, as far as the invariant knows


def test_return_inside_loop():
    good = src("""
        def early(n: int) -> int:
            requires n >= 3
            ensures result == 3
            i = 0
            while i < n:
                invariant i >= 0
                invariant i <= 3
                if i == 3:
                    return i
                i = i + 1
            return 3
        """)
    assert set(statuses(verify(good)).values()) == {"verified"}
    bad = good.replace("return i\n", "return i + 1\n")
    st = statuses(verify(bad))
    assert st["loop at line 5: invariant is preserved by the body"] == "failed"


def test_nested_loops():
    results = verify(src("""
        def mul(a: int, b: int) -> int:
            requires a >= 0
            requires b >= 0
            ensures result == a * b
            r = 0
            i = 0
            while i < a:
                invariant i <= a
                invariant r == i * b
                j = 0
                while j < b:
                    invariant j <= b
                    invariant r == i * b + j
                    r = r + 1
                    j = j + 1
                i = i + 1
            return r
        """))
    assert len(results) == 6
    assert {r["status"] for r in results} == {"verified"}, results


def test_unknown_is_reported_as_inconclusive(example, capsys):
    namespace = {"__name__": "veri_generated"}
    exec(compile_source(example("max2.veri"), "max2.veri"), namespace)

    class UnknownSolver:
        def set(self, *args): pass
        def add(self, *args): pass
        def check(self): return namespace["unknown"]
        def reason_unknown(self): return "timeout"

    namespace["Solver"] = UnknownSolver
    results = namespace["verify_all"](namespace["FUNCTIONS"], verbose=True)
    assert {r["status"] for r in results} == {"unknown"}
    assert namespace["main"](namespace["FUNCTIONS"], []) == 2
    out = capsys.readouterr().out
    assert "[INCONCLUSIVE]" in out and "z3 returned unknown: timeout" in out


def test_identifiers_clashing_with_generated_names():
    results = verify(src("""
        def f(And: int, s: int) -> int:
            ensures result >= And
            sat = And + s * s
            return sat
        """))
    assert [r["status"] for r in results] == ["verified"]


def test_run_generated_matches_committed_output(example):
    """examples/generated/*.py must be up to date with the compiler."""
    for path in sorted(EXAMPLES.glob("*.veri")):
        name = path.stem
        committed = (EXAMPLES / "generated" / f"{name}.py").read_text(encoding="utf-8")
        assert committed == compile_source(example(f"{name}.veri"), f"{name}.veri"), name
        assert run_generated(committed, verbose=False)
