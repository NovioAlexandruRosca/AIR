# veri language specification

veri is a small imperative language with Hoare-style contracts. veri checks a
program's verification conditions (VCs) with the z3 SMT solver, either
in-process or through a generated standalone Python script.

## 1. Lexical structure

* **Block syntax: indentation based**, like Python. A line ending in `:` opens a
  block; the block is the following lines indented further than that line.
  Indentation must use spaces (a tab in leading whitespace is an error). Dedenting
  to a column that matches no enclosing block is an error.
* Line breaks inside `( )` and `[ ]` are ignored. A bracket that is never closed
  is reported at the bracket itself.
* Comments start with `#` and run to the end of the line.
* Identifiers: `[A-Za-z_][A-Za-z0-9_]*`. Integer literals: `[0-9]+` (no sign; use
  unary minus).
* Keywords: `def return if elif else while requires ensures invariant decreases
  forall exists in and or not True False`.
* Operators and punctuation:
  `<==> ==> -> >= <= == != // .. && || > < = + - * % ! ( ) [ ] : ,`.
  `&&`, `||` and `!` are aliases of `and`, `or` and `not`. A single `/`, `&` or `|`
  is rejected with a hint (`//`, `and`, `or`).
* `result` is reserved by the type checker for the return value inside `ensures`.
  `len`, `append`, `abs`, `min` and `max` name builtins.

## 2. Grammar (EBNF)

`NEWLINE`, `INDENT` and `DEDENT` are produced by the lexer as in Python.
`{ x }` means zero or more, `[ x ]` optional.

```ebnf
program     = { function } EOF ;

function    = "def" NAME "(" [ params ] ")" "->" type ":" NEWLINE
              INDENT { contract NEWLINE } stmt { stmt } DEDENT ;
params      = param { "," param } ;
param       = NAME ":" type ;
type        = "int" | "bool" | "array" ;
contract    = "requires" expr | "ensures" expr | "decreases" expr ;   (* at most one decreases *)

block       = ":" NEWLINE INDENT stmt { stmt } DEDENT ;
stmt        = NAME "=" expr NEWLINE                    (* assignment *)
            | NAME "[" expr "]" "=" expr NEWLINE       (* array element assignment *)
            | "return" expr NEWLINE
            | "if" expr block { "elif" expr block } [ "else" block ]
            | "while" expr ":" NEWLINE
              INDENT "invariant" expr NEWLINE { "invariant" expr NEWLINE } stmt { stmt } DEDENT ;

expr        = iff ;
iff         = implies { "<==>" implies } ;
implies     = or [ "==>" implies ] ;                   (* right-associative *)
or          = and { ( "or" | "||" ) and } ;
and         = not { ( "and" | "&&" ) not } ;
not         = ( "not" | "!" ) not | quantifier | comparison ;
quantifier  = ( "forall" | "exists" ) NAME "in" arith ".." arith ":" expr ;
comparison  = arith { cmp_op arith } ;                 (* a < b < c  means  a < b and b < c *)
cmp_op      = "<" | "<=" | ">" | ">=" | "==" | "!=" ;
arith       = term { ( "+" | "-" ) term } ;
term        = unary { ( "*" | "//" | "%" ) unary } ;
unary       = "-" unary | postfix ;
postfix     = atom { "[" expr "]" } ;
atom        = INT | "True" | "False" | NAME
            | NAME "(" [ args ] ")"                     (* builtin or user function call *)
            | "[" [ args ] "]"                          (* array literal *)
            | "(" expr ")" ;
args        = expr { "," expr } ;
```

Operator precedence, loosest first:
quantifier body, `<==>`, `==>`, `or`, `and`, `not`, comparisons, `+ -`,
`* // %`, unary `-`, indexing. A quantifier body extends as far right as
possible. `elif c: B ...` is sugar for `else:` followed by a nested `if c: B ...`.

## 3. Types and static rules

| type | values | z3 encoding |
|---|---|---|
| `int` | mathematical (unbounded) integers | `Int` |
| `bool` | `True`, `False` | `Bool` |
| `array` | finite sequences of ints, **value semantics** (no aliasing) | datatype `IntArray = mk_array(data: Array(Int, Int), length: Int)` |

| operation | types |
|---|---|
| `+ - *`, unary `-` | int → int |
| `//`, `%` | int → int, Python semantics (`//` rounds down, `%` has the sign of the divisor) |
| `< <= > >=` | int, int → bool |
| `== !=` | int, int → bool; bool, bool → bool |
| `and or ==> <==>`, `not` | bool → bool (`and`, `or` and `==>` short-circuit) |
| `a[i]` | array, int → int |
| `len(a)`, `append(a, x)` | array → int; array, int → array |
| `abs(x)`, `min(x, y)`, `max(x, y)` | int → int |
| `[e1, ..., en]` | ints → array |
| `forall/exists k in lo .. hi: P` | `k` ranges over ints with `lo <= k < hi`; `P` bool |

Rules:

* Conditions (`if`, `while`) and all contracts are `bool`; `decreases` is `int`.
* Quantifiers may only appear in `requires`, `ensures` and `invariant`. A
  quantified name must not shadow a parameter, a local, `result` or an enclosing
  quantified name.
* Contracts cannot call user-defined functions (builtins are fine).
* Parameters are **immutable** (no `p = ...`, no `p[i] = ...`), so `ensures`
  always refers to the input values.
* Locals are declared by their first assignment. Every read must be preceded by
  an assignment on every path (definite assignment).
* `requires` and `decreases` may mention only parameters. `ensures` may mention
  only parameters and `result`. `invariant` may mention parameters and locals
  assigned before the loop.
* Every path through a function must end in `return`, and code after a `return`
  in the same block is rejected as unreachable.
* Every `while` loop needs at least one `invariant`.
* Every function on a call cycle (direct or mutual recursion) needs a
  `decreases` clause. Neither invariants nor measures are inferred.

Every error carries a 1-based line and column. The CLI prints
`file:line:col: kind: message` followed by the offending line and a caret.

## 4. Verification conditions

VCs are computed by weakest preconditions, backwards over the body (`Post` is the
conjunction of the `ensures` clauses):

```
wp(x = e, Q)              = Q[x := e]
wp(x[i] = e, Q)           = Q[x := x with element i set to e]
wp(return e, Q)           = Post[result := e]
wp(S1; S2, Q)             = wp(S1, wp(S2, Q))
wp(if c: A else: B, Q)    = (c ==> wp(A, Q)) and (not c ==> wp(B, Q))
wp(while c inv I: B, Q)   = I
                            and forall modified(B). (I and c     ==> wp(B, I))
                            and forall modified(B). (I and not c ==> Q)
```

**Calls are modular.** A call `f(args)` is replaced by a fresh variable (e.g.
`f@call14`):

* the caller must prove `f`'s `requires` for `args`;
* the caller may assume `f`'s `ensures` for `args` and the returned value;
* `f`'s body is never inspected, so a recursive call simply uses `f`'s own
  contract;
* inside a recursion cycle, the caller must also prove `0 <= measure_f(args)`
  and `measure_f(args) < measure_caller`, which guarantees termination.

**Safety.** Every `a[i]` (or `a[i] = e`) evaluated by code must have
`0 <= i < len(a)`, and every `x // y` or `x % y` must have `y != 0`. Each check
is guarded by the short-circuit condition under which it runs (in
`i < len(a) and a[i] > 0`, the check of `a[i]` may assume `i < len(a)`).
Contracts are specifications, not code: an out-of-range `a[i]` there is just an
unspecified integer.

Each obligation becomes one VC, checked as `WF and requires ==> obligation`.
`WF` says that array lengths are non-negative.

| VC kind | meaning |
|---|---|
| `ensures` | one per `ensures` clause reached by a `return` that is not after a loop |
| `safety` | an index is in bounds / a divisor is non-zero |
| `call-pre` | a callee's `requires` holds at a call |
| `termination` | the `decreases` measure is `>= 0` and decreases at a recursive call |
| `loop-entry` | the invariant holds when the loop is first reached |
| `loop-preserve` | from any state with `I and c`, one execution of the body re-establishes `I` (or returns satisfying `Post`) |
| `loop-exit` | from any state with `I and not c`, the rest of the function establishes its goals |

Implementation notes:

* **Havoc by fresh constants.** The variables a loop assigns are renamed to
  fresh constants such as `i@loop9` ("`i` at the start of an arbitrary iteration
  of the loop on line 9"). Universally quantifying them in a positive position
  is the same as leaving them free in a validity check. Variables the loop does
  not assign keep their names and values, so they need not be repeated in the
  invariant.
* **Obligations travel with their context.** A side condition is created where
  it arises and pushed back through the preceding statements by the same rules.
  It is therefore guarded by the enclosing branch conditions and, inside loops,
  by the loop's `I and c`.
* **Labels.** Every VC fragment that comes from a source clause (a `requires`,
  an invariant, a branch condition, a callee's `ensures`, ...) carries that clause
  and its source text. The meaning is unchanged; the labels are used only to
  explain failures.
* With nested loops, when the outer body ends with the inner loop, re-establishing
  the outer invariant is checked in the inner loop's `loop-exit` VC.

## 5. Checking and explanations

For each VC, the checker creates a `z3.Solver`, adds `Not(VC)` and calls
`check()`:

* `unsat`: no values violate the VC, so it is **verified**;
* `sat`: the VC is **violated**, and the model is a counterexample;
* `unknown` (e.g. a hard nonlinear problem, or the per-VC timeout of 10 s by
  default): **inconclusive**.

On `sat`, the checker first looks for a model with small values: array length
≤ 3 and values ≤ 3, then larger bounds. It then explains the counterexample in
source terms:

```
  [FAILED]       loop at line 16: invariant is preserved by the body  (line 16)
      z3: Not(VC) is sat, so the VC can be violated
      counterexample:
        a = [0, -1, -1]                       (parameter)
        i = 2, out = [0]                      (at the start of an arbitrary iteration of the loop at line 16)
      assuming:
        invariant (line 17): i >= 0
        ...
        loop condition (line 16) holds: i < len(a)
        if (line 24) is false: len(out) == 0
        elif (line 26) is true: a[i] >= a[i - 1]
      these do not hold:
        invariant (line 20) again after the body: forall p in 1 .. len(out): out[p - 1] <= out[p]
          where out = [0, -1]
          fails for p = 1:
            out[p - 1] <= out[p]   is   0 <= -1   which is false
```

* **counterexample**: the values of the VC's variables, grouped by what they
  stand for: parameters, loop state (`i@loop16` is shown as `i`), or results of
  calls (shown as the call, e.g. `sum_rec(n - 2) = 0`).
* **assuming**: the hypotheses on the failing path: `requires`, invariants,
  the loop condition, the branches taken, and the `ensures` of the calls made.
* **does not hold**: each clause that is false, with the program state at that
  point (`where ...`, or "with the call's arguments" for a callee's `requires`).
  The checker then explains why the clause is false:
  * for `forall`, a concrete index where it fails (found with z3);
  * for `or`, each alternative;
  * for a comparison, both sides evaluated.

A loop counterexample satisfies the invariant but is not necessarily reachable
from a real input. It shows that the invariant, as written, does not carry the
proof.

`--raw` adds z3's raw model and `--show-z3` adds the VC as given to z3. `--brief`
prints one line per VC. The exit status is 0 when everything is verified, 1 when
a VC fails, and 2 when a VC is inconclusive.
