import pytest

from veri.driver import check
from veri.errors import TypeCheckError
from veri.typecheck import INT

from .conftest import src


def test_examples_typecheck(example):
    from .conftest import EXAMPLES
    for path in sorted(EXAMPLES.glob("*.veri")):
        check(example(path.name))


def test_recursion_groups(example):
    infos = check(example("recursion.veri")).by_name
    assert infos["sum_rec"].recursive_group == {"sum_rec"}
    assert infos["is_even"].recursive_group == {"is_even", "is_odd"}
    assert check(example("max3.veri")).by_name["max3"].recursive_group == frozenset()


def test_local_types_are_inferred(example):
    info = check(example("sum.veri")).functions[0]
    assert info.param_types == {"n": INT}
    assert info.local_types == {"s": INT, "i": INT}


TYPE_ERRORS = [
    pytest.param(
        """
        def f(a: str) -> int:
            return 0
        """, 1, 10, "type 'str' is not supported", id="str-type"),
    pytest.param(
        """
        def f(a: float) -> int:
            return 0
        """, 1, 10, "unknown type 'float'", id="unknown-type"),
    pytest.param(
        """
        def f(a: int) -> int:
            a = 1
            return a
        """, 2, 5, "cannot assign to parameter 'a'", id="assign-param"),
    pytest.param(
        """
        def f(a: int) -> int:
            return z
        """, 2, 12, "undefined variable 'z'", id="undefined"),
    pytest.param(
        """
        def f(a: int) -> int:
            if a > 0:
                x = 1
            return x
        """, 4, 12, "may be used before it is assigned", id="maybe-unassigned"),
    pytest.param(
        """
        def f(a: int) -> int:
            requires result > 0
            return a
        """, 2, 14, "'result' can only be used in 'ensures'", id="result-in-requires"),
    pytest.param(
        """
        def f(a: int) -> int:
            ensures result > x
            x = a
            return x
        """, 2, 22, "'x' is a local variable", id="local-in-ensures"),
    pytest.param(
        """
        def f(a: int) -> int:
            if a > 0:
                return a
        """, 1, 1, "may reach the end of its body without returning", id="missing-return"),
    pytest.param(
        """
        def f(a: int) -> int:
            return a
            return 0
        """, 3, 5, "unreachable code after 'return'", id="unreachable"),
    pytest.param(
        """
        def f(n: int) -> int:
            while n > 0:
                invariant i >= 0
                i = 1
            return 0
        """, 3, 19, "may be used before it is assigned", id="invariant-uses-later-local"),
    pytest.param(
        """
        def f(a: int) -> int:
            return g(a)
        """, 2, 12, "unknown function 'g'", id="unknown-function"),
    pytest.param(
        """
        def f(a: array) -> int:
            return len(a, a)
        """, 2, 12, "len() takes 1 argument(s), got 2", id="builtin-arity"),
    pytest.param(
        """
        def f(a: int) -> int:
            return a[0]
        """, 2, 12, "cannot index a value of type int", id="index-int"),
    pytest.param(
        """
        def f(a: array) -> int:
            return a
        """, 2, 5, "return type mismatch: expected int, got array", id="return-array-as-int"),
    pytest.param(
        """
        def f(a: array) -> int:
            if a == a:
                return 1
            return 0
        """, 2, 8, "cannot compare array with array", id="compare-arrays"),
    pytest.param(
        """
        def f(a: array) -> int:
            a[0] = 1
            return 0
        """, 2, 5, "cannot assign to parameter 'a'", id="store-into-param"),
    pytest.param(
        """
        def f(a: array) -> int:
            ensures forall a in 0 .. 3: result >= 0
            return 0
        """, 2, 13, "quantified variable 'a' would shadow", id="forall-shadows-param"),
    pytest.param(
        """
        def f(n: int) -> int:
            ensures forall i in 0 .. n: result >= i
            i = 0
            return i
        """, 2, 13, "quantified variable 'i' would shadow", id="forall-shadows-local"),
    pytest.param(
        """
        def f(a: int) -> int:
            if a:
                return a
            return 0
        """, 2, 8, "the 'if' condition must be bool, got int", id="int-condition"),
    pytest.param(
        """
        def f(a: int) -> int:
            ensures result + 1
            return a
        """, 2, 13, "an 'ensures' clause must be bool, got int", id="int-ensures"),
    pytest.param(
        """
        def f(a: int) -> int:
            return a or 1
        """, 2, 12, "operator 'or' is not defined for int and int", id="or-on-ints"),
    pytest.param(
        """
        def f(a: bool) -> int:
            return a + 1
        """, 2, 12, "operator '+' is not defined for bool and int", id="bool-arithmetic"),
    pytest.param(
        """
        def f(a: bool, b: bool) -> bool:
            return a < b
        """, 2, 12, "cannot compare bool with bool using '<'", id="ordering-bools"),
    pytest.param(
        """
        def f(a: array) -> int:
            if forall k in 0 .. len(a): a[k] > 0:
                return 1
            return 0
        """, 2, 8, "'forall' is only allowed in requires, ensures and invariant", id="forall-in-code"),
    pytest.param(
        """
        def g(x: int) -> int:
            return x

        def f(a: int) -> int:
            ensures result == g(a)
            return g(a)
        """, 5, 23, "calls to user-defined functions are not allowed in 'ensures'", id="call-in-contract"),
    pytest.param(
        """
        def f(n: int) -> int:
            if n <= 0:
                return 0
            return f(n - 1)
        """, 1, 1, "recursive function 'f' needs a 'decreases' clause", id="recursion-without-decreases"),
    pytest.param(
        """
        def f(n: int) -> int:
            decreases k
            k = n
            return k
        """, 2, 15, "'decreases' may only refer to parameters", id="decreases-on-local"),
    pytest.param(
        """
        def f(a: int) -> int:
            return g(a, 1)

        def g(x: int) -> int:
            return x
        """, 2, 12, "g() takes 1 argument(s), got 2", id="call-arity"),
    pytest.param(
        """
        def len(a: array) -> int:
            return 0
        """, 1, 1, "'len' is a builtin function", id="redefine-builtin"),
    pytest.param(
        """
        def f(a: int, a: int) -> int:
            return a
        """, 1, 15, "duplicate parameter 'a'", id="duplicate-param"),
    pytest.param(
        """
        def f(a: int) -> int:
            return a
        def f(b: int) -> int:
            return b
        """, 3, 1, "already defined at line 1", id="duplicate-function"),
]


@pytest.mark.parametrize("source, line, col, fragment", TYPE_ERRORS)
def test_type_errors(source, line, col, fragment):
    with pytest.raises(TypeCheckError) as ei:
        check(src(source))
    assert fragment in ei.value.message
    assert (ei.value.line, ei.value.col) == (line, col), str(ei.value)


def test_variable_assigned_on_both_branches_is_defined():
    check(src("""
        def f(a: int) -> int:
            if a > 0:
                x = 1
            else:
                x = 2
            return x
        """))
