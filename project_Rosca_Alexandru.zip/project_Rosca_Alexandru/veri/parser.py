"""Stage 2: recursive-descent parser producing the AST in `astnodes`.

The grammar is given in docs/SPEC.md; each `parse_*` method below implements
one production of it. Expression precedence, loosest first:

    forall/exists  <==>  ==>  or  and  not  comparisons  + -  * // %  unary -  x[i]
"""

from __future__ import annotations

from . import astnodes as A
from .astnodes import CMP_OPS
from .errors import ParseError
from .lexer import Token, tokenize


def describe(tok: Token) -> str:
    if tok.kind == "NAME":
        return f"identifier {tok.text!r}"
    if tok.kind == "INT":
        return f"integer {tok.text}"
    return {
        "NEWLINE": "end of line",
        "INDENT": "unexpected indent",
        "DEDENT": "end of block",
        "EOF": "end of file",
    }.get(tok.kind, repr(tok.text))


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.i = 0

    # ---- helpers ---------------------------------------------------------

    @property
    def tok(self) -> Token:
        return self.tokens[self.i]

    def peek(self, offset: int = 1) -> Token:
        return self.tokens[min(self.i + offset, len(self.tokens) - 1)]

    def at(self, *kinds: str) -> bool:
        return self.tok.kind in kinds

    def advance(self) -> Token:
        t = self.tok
        if t.kind != "EOF":
            self.i += 1
        return t

    def error(self, msg: str, tok: Token | None = None) -> ParseError:
        return ParseError(msg, (tok or self.tok).pos)

    def expect(self, kind: str, what: str | None = None) -> Token:
        if self.tok.kind != kind:
            want = what or {"NAME": "an identifier", "NEWLINE": "end of line", "INDENT": "an indented block"}.get(
                kind, repr(kind)
            )
            raise self.error(f"expected {want}, got {describe(self.tok)}")
        return self.advance()

    # ---- declarations ----------------------------------------------------

    def parse_program(self) -> A.Program:
        prog = A.Program()
        while not self.at("EOF"):
            if self.at("NEWLINE"):
                self.advance()
                continue
            if not self.at("def"):
                raise self.error(f"expected 'def' at top level, got {describe(self.tok)}")
            prog.functions.append(self.parse_function())
        return prog

    def parse_type(self) -> A.TypeRef:
        t = self.expect("NAME", "a type name")
        return A.TypeRef(t.text, t.pos)

    def parse_function(self) -> A.Function:
        start = self.expect("def")
        name = self.expect("NAME", "a function name")
        self.expect("(")
        params: list[A.Param] = []
        if not self.at(")"):
            while True:
                p = self.expect("NAME", "a parameter name")
                self.expect(":", "':' and a type after the parameter name")
                params.append(A.Param(p.text, self.parse_type(), p.pos))
                if not self.at(","):
                    break
                self.advance()
        self.expect(")")
        self.expect("->", "'->' and a return type")
        ret = self.parse_type()
        self.expect(":")
        self.expect("NEWLINE")
        self.expect("INDENT")

        requires: list[A.Expr] = []
        ensures: list[A.Expr] = []
        decreases: A.Expr | None = None
        while self.at("requires", "ensures", "decreases", "NEWLINE"):
            if self.at("NEWLINE"):
                self.advance()
                continue
            kw = self.advance()
            e = self.parse_expr()
            self.expect("NEWLINE")
            if kw.kind == "requires":
                requires.append(e)
            elif kw.kind == "ensures":
                ensures.append(e)
            elif decreases is not None:
                raise self.error("a function can have only one 'decreases' clause", kw)
            else:
                decreases = e
        if self.at("invariant"):
            raise self.error("'invariant' is only allowed at the start of a while loop body")

        body = self.parse_stmts(start, "function body")
        return A.Function(name.text, params, ret, requires, ensures, body, start.pos, decreases)

    # ---- statements ------------------------------------------------------

    def parse_stmts(self, owner: Token, what: str) -> list[A.Stmt]:
        """Statements up to (and consuming) the DEDENT that closes the block."""
        stmts: list[A.Stmt] = []
        while not self.at("DEDENT", "EOF"):
            if self.at("NEWLINE"):
                self.advance()
                continue
            stmts.append(self.parse_stmt())
        if not stmts:
            raise self.error(f"{what} must contain at least one statement", owner)
        self.expect("DEDENT")
        return stmts

    def parse_block(self, owner: Token, what: str) -> list[A.Stmt]:
        self.expect(":")
        self.expect("NEWLINE")
        self.expect("INDENT")
        return self.parse_stmts(owner, what)

    def parse_stmt(self) -> A.Stmt:
        t = self.tok
        if t.kind == "return":
            self.advance()
            value = self.parse_expr()
            self.expect("NEWLINE")
            return A.Return(value, t.pos)
        if t.kind == "if":
            return self.parse_if()
        if t.kind == "while":
            return self.parse_while()
        if t.kind == "NAME" and self.peek().kind == "=":
            self.advance()
            self.advance()
            value = self.parse_expr()
            self.expect("NEWLINE")
            return A.Assign(t.text, value, t.pos)
        if t.kind == "NAME" and self.peek().kind == "[":
            self.advance()
            self.advance()
            index = self.parse_expr()
            self.expect("]")
            self.expect("=", "'=' (only `x = e` and `x[i] = e` are statements)")
            value = self.parse_expr()
            self.expect("NEWLINE")
            return A.AssignIndex(t.text, index, value, t.pos)
        if t.kind in ("requires", "ensures", "decreases"):
            raise self.error(f"'{t.kind}' clauses must come before the first statement of the function")
        if t.kind == "invariant":
            raise self.error("'invariant' clauses must come first in the while loop body")
        if t.kind == "else":
            raise self.error("'else' without a matching 'if'")
        if t.kind == "elif":
            raise self.error("'elif' without a matching 'if'")
        if t.kind == "INDENT":
            raise self.error("unexpected indent")
        raise self.error(f"expected a statement, got {describe(t)}")

    def parse_if(self) -> A.If:
        start = self.advance()  # 'if' or 'elif'
        cond = self.parse_expr()
        then_body = self.parse_block(start, f"'{start.kind}' branch")
        else_body: list[A.Stmt] = []
        if self.at("elif"):
            else_body = [self.parse_if()]
        elif self.at("else"):
            e = self.advance()
            else_body = self.parse_block(e, "'else' branch")
        return A.If(cond, then_body, else_body, start.pos, start.kind)

    def parse_while(self) -> A.While:
        start = self.advance()
        cond = self.parse_expr()
        self.expect(":")
        self.expect("NEWLINE")
        self.expect("INDENT")
        invariants: list[A.Expr] = []
        while self.at("invariant", "NEWLINE"):
            if self.advance().kind == "invariant":
                invariants.append(self.parse_expr())
                self.expect("NEWLINE")
        if not invariants:
            raise self.error(
                "while loop needs at least one 'invariant' clause (invariants are not inferred)", start
            )
        body = self.parse_stmts(start, "while loop body")
        return A.While(cond, invariants, body, start.pos)

    # ---- expressions -----------------------------------------------------

    def parse_expr(self) -> A.Expr:
        return self.parse_iff()

    def parse_iff(self) -> A.Expr:
        left = self.parse_implies()
        while self.at("<==>"):
            self.advance()
            left = A.BinOp("<==>", left, self.parse_implies(), left.pos)
        return left

    def parse_implies(self) -> A.Expr:
        left = self.parse_or()
        if self.at("==>"):
            self.advance()
            return A.BinOp("==>", left, self.parse_implies(), left.pos)  # right-associative
        return left

    def parse_or(self) -> A.Expr:
        left = self.parse_and()
        while self.at("or"):
            self.advance()
            left = A.BinOp("or", left, self.parse_and(), left.pos)
        return left

    def parse_and(self) -> A.Expr:
        left = self.parse_not()
        while self.at("and"):
            self.advance()
            left = A.BinOp("and", left, self.parse_not(), left.pos)
        return left

    def parse_not(self) -> A.Expr:
        if self.at("not"):
            t = self.advance()
            return A.UnaryOp("not", self.parse_not(), t.pos)
        if self.at("forall", "exists"):
            return self.parse_quant()
        return self.parse_comparison()

    def parse_quant(self) -> A.Quant:
        start = self.advance()
        var = self.expect("NAME", "the quantified variable name")
        self.expect("in", "'in' and a range `lo .. hi`")
        lo = self.parse_arith()
        self.expect("..", "'..' in the range `lo .. hi`")
        hi = self.parse_arith()
        self.expect(":", "':' after the quantifier range")
        return A.Quant(start.kind, var.text, lo, hi, self.parse_expr(), start.pos)

    def parse_comparison(self) -> A.Expr:
        """`a < b <= c` means `a < b and b <= c`, as in Python."""
        operands = [self.parse_arith()]
        ops: list[str] = []
        while self.at(*CMP_OPS):
            ops.append(self.advance().kind)
            operands.append(self.parse_arith())
        if not ops:
            return operands[0]
        result: A.Expr | None = None
        for op, left, right in zip(ops, operands, operands[1:]):
            cmp = A.BinOp(op, left, right, left.pos)
            result = cmp if result is None else A.BinOp("and", result, cmp, result.pos)
        return result

    def parse_arith(self) -> A.Expr:
        left = self.parse_term()
        while self.at("+", "-"):
            op = self.advance()
            left = A.BinOp(op.kind, left, self.parse_term(), left.pos)
        return left

    def parse_term(self) -> A.Expr:
        left = self.parse_unary()
        while self.at("*", "//", "%"):
            op = self.advance()
            left = A.BinOp(op.kind, left, self.parse_unary(), left.pos)
        return left

    def parse_unary(self) -> A.Expr:
        if self.at("-"):
            t = self.advance()
            return A.UnaryOp("-", self.parse_unary(), t.pos)
        return self.parse_postfix()

    def parse_postfix(self) -> A.Expr:
        e = self.parse_atom()
        while self.at("["):
            self.advance()
            index = self.parse_expr()
            self.expect("]")
            e = A.Index(e, index, e.pos)
        return e

    def parse_atom(self) -> A.Expr:
        t = self.tok
        if t.kind == "INT":
            self.advance()
            return A.IntLit(int(t.text), t.pos)
        if t.kind in ("True", "False"):
            self.advance()
            return A.BoolLit(t.kind == "True", t.pos)
        if t.kind == "NAME":
            self.advance()
            if self.at("("):
                self.advance()
                return A.Call(t.text, self.parse_args(")"), t.pos)
            return A.Name(t.text, t.pos)
        if t.kind == "[":
            self.advance()
            return A.ArrayLit(self.parse_args("]"), t.pos)
        if t.kind == "(":
            self.advance()
            e = self.parse_expr()
            self.expect(")")
            return e
        if t.kind in ("forall", "exists"):
            return self.parse_quant()
        raise self.error(f"expected an expression, got {describe(t)}")

    def parse_args(self, close: str) -> list[A.Expr]:
        """Comma-separated expressions up to and including the closing token."""
        args: list[A.Expr] = []
        if not self.at(close):
            args.append(self.parse_expr())
            while self.at(","):
                self.advance()
                args.append(self.parse_expr())
        self.expect(close)
        return args


def parse(source: str) -> A.Program:
    return Parser(tokenize(source)).parse_program()
