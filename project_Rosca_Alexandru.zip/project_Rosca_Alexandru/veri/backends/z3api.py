"""In-process z3 checking: build each VC tree from live z3 objects and check it now.

This is what `veri compile` / `veri verify` run. The trees and the checking
code are exactly those of the standalone script (`z3tree.py`, `z3runtime.py`);
only the builder differs: here it makes z3 objects instead of source text.
"""

from __future__ import annotations

from typing import Any, Callable

import z3

from .. import logic as L
from ..typecheck import ARRAY, BOOL, INT, Type
from ..vcgen import FunctionVCs
from . import z3runtime as R
from .z3tree import Builder, TreeConverter

#: How a variable of each source type becomes a z3 constant.
Z3_CONST: dict[Type, Callable[[str], z3.ExprRef]] = {
    INT: z3.Int,
    BOOL: z3.Bool,
    ARRAY: lambda name: z3.Const(name, R.IntArray),
}

OPS: dict[str, Callable[..., Any]] = {
    "+": lambda a, b: a + b, "-": lambda a, b: a - b, "*": lambda a, b: a * b,
    "//": R.py_div, "%": R.py_mod, **R.CMP,
    "neg": lambda a: -a, "not": z3.Not, "and": lambda *a: z3.And(*a), "or": lambda *a: z3.Or(*a),
    "implies": z3.Implies, "iff": lambda a, b: a == b, "ite": z3.If,
    "forall": lambda v, b: z3.ForAll([v], b), "exists": lambda v, b: z3.Exists([v], b),
    "empty": lambda: R.EMPTY_ARRAY, "len": lambda a: R.IntArray.length(a),
    "select": lambda a, i: z3.Select(R.IntArray.data(a), i), "store": R.array_store, "append": R.array_append,
}


class ObjectBuilder(Builder):
    def __init__(self) -> None:
        self.consts: dict[tuple[str, Type], z3.ExprRef] = {}

    def var(self, v: L.Var) -> z3.ExprRef:
        key = (v.name, v.type)
        if key not in self.consts:
            self.consts[key] = Z3_CONST[v.type](v.name)
        return self.consts[key]

    def const(self, value: int) -> z3.ExprRef:
        return z3.IntVal(value)

    def boollit(self, value: bool) -> z3.ExprRef:
        return z3.BoolVal(value)

    def apply(self, op: str, *args: Any) -> Any:
        return OPS[op](*args)

    def node(self, kind: str, text: str, *parts: Any) -> tuple:
        return (kind, text, *parts)

    def seq(self, items: list[Any]) -> list[Any]:
        return items

    def env_entry(self, name: str, var: Any, value: Any) -> tuple:
        return (name, var, value)


def to_z3(functions: list[FunctionVCs]):
    """The VCs as (name, line, make_vcs) entries, the format `z3runtime.verify_all` takes."""
    entries = []
    for fn in functions:
        def make_vcs(fn=fn):
            b = ObjectBuilder()
            conv = TreeConverter(b)
            out = []
            for vc in fn.vcs:
                variables = [(b.var(v), *vc.var_info[v.name]) for v in vc.variables]
                out.append((vc.name, vc.pos.line, conv.tree(vc.formula), variables))
            return out
        entries.append((fn.name, fn.pos.line, make_vcs))
    return entries


def check(functions: list[FunctionVCs], verbose: bool = True, details: bool = False,
          show_z3: bool = False, raw: bool = False, timeout_ms: int = 10_000) -> list[dict]:
    """Send every VC to z3 now. Returns the per-VC result dicts from `z3runtime.check_vc`."""
    R.TIMEOUT_MS = timeout_ms
    return R.verify_all(to_z3(functions), verbose=verbose, details=details, show_z3=show_z3, raw=raw)
