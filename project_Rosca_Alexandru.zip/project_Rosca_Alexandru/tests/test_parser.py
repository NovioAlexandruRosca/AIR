import pytest

from veri import astnodes as A
from veri.errors import CompileError, ParseError
from veri.parser import parse

from .conftest import src


def expr(text: str) -> A.Expr:
    """Parse a single expression (as the value of a return statement)."""
    return parse(f"def f(a: int) -> int:\n    return {text}\n").functions[0].body[0].value


def test_parse_max2(example):
    prog = parse(example("max2.veri"))
    (f,) = prog.functions
    assert f.name == "max2"
    assert [(p.name, p.type.name) for p in f.params] == [("a", "int"), ("b", "int")]
    assert f.return_type.name == "int"
    assert f.requires == []
    assert [A.show_expr(c) for c in f.ensures] == ["result >= a", "result >= b", "result == a or result == b"]
    (stmt,) = f.body
    assert isinstance(stmt, A.If)
    assert A.show_expr(stmt.cond) == "a >= b"
    assert isinstance(stmt.then_body[0], A.Return) and isinstance(stmt.else_body[0], A.Return)
    assert (f.pos.line, f.pos.col) == (3, 1)


def test_parse_while_with_invariants(example):
    f = parse(example("sum.veri")).functions[0]
    loop = f.body[2]
    assert isinstance(loop, A.While)
    assert [A.show_expr(i) for i in loop.invariants] == ["i <= n + 1", "2 * s == (i - 1) * i"]
    assert [type(s).__name__ for s in loop.body] == ["Assign", "Assign"]
    assert (loop.pos.line, loop.pos.col) == (9, 5)


def test_elif_desugars_to_nested_if(example):
    f = parse(example("max3_nonstrict_compare.veri")).functions[0]
    top = f.body[0]
    (inner,) = top.else_body
    assert isinstance(inner, A.If) and inner.keyword == "elif"
    assert A.show_expr(inner.cond) == "b >= a and b >= c"


def test_precedence_and_unary_minus():
    e = expr("-a + 2 * (a - 1) - 3")
    assert A.show_expr(e) == "-a + 2 * (a - 1) - 3"
    assert isinstance(e, A.BinOp) and e.op == "-"  # left-associative: ((-a + ...) - 3)


def test_logic_precedence():
    # <==> loosest, then ==> (right-assoc), or, and, not, comparisons
    e = expr("a > 0 or a < 0 and not a == 5 ==> a != 0 ==> True <==> False")
    assert e.op == "<==>"
    imp = e.left
    assert imp.op == "==>" and imp.right.op == "==>"  # right-associative
    assert imp.left.op == "or" and imp.left.right.op == "and"
    assert isinstance(imp.left.right.right, A.UnaryOp) and imp.left.right.right.op == "not"
    assert A.show_expr(e) == "a > 0 or a < 0 and not a == 5 ==> a != 0 ==> True <==> False"
    assert A.show_expr(expr(A.show_expr(e))) == A.show_expr(e)  # printing round-trips


def test_aliases_and_chained_comparisons():
    assert A.show_expr(expr("!(a > 0) && a > -5 || a == 9")) == "not a > 0 and a > -5 or a == 9"
    chain = expr("0 <= a < 10")
    assert chain.op == "and"
    assert A.show_expr(chain) == "0 <= a and a < 10"


def test_division_and_modulo():
    e = expr("a // 2 % 3 * 4")
    assert A.show_expr(e) == "a // 2 % 3 * 4"
    assert e.op == "*" and e.left.op == "%" and e.left.left.op == "//"


def test_quantifier_body_extends_right():
    f = parse(src("""
        def f(a: array) -> int:
            ensures forall k in 0 .. len(a): a[k] > 0 or exists j in 0 .. k: a[j] == 1
            return 0
        """)).functions[0]
    (q,) = f.ensures
    assert isinstance(q, A.Quant) and q.kind == "forall"
    assert q.body.op == "or" and isinstance(q.body.right, A.Quant) and q.body.right.kind == "exists"


def test_decreases_clause():
    f = parse(src("""
        def f(n: int) -> int:
            requires n >= 0
            decreases n
            ensures result >= 0
            return 0
        """)).functions[0]
    assert A.show_expr(f.decreases) == "n"


PARSE_ERRORS = [
    pytest.param(
        """
        def f(a: int) -> int
            return a
        """, 1, 21, "expected ':', got end of line", id="missing-colon"),
    pytest.param(
        """
        def f(a) -> int:
            return a
        """, 1, 8, "expected ':' and a type", id="missing-param-type"),
    pytest.param(
        """
        def f(a: int) -> int:
            if a >:
                return a
            return 0
        """, 2, 11, "expected an expression, got ':'", id="incomplete-comparison"),
    pytest.param(
        """
        def f(a: int) -> int:
            ensures result > 0 and
            return a
        """, 2, 27, "expected an expression, got end of line", id="dangling-and"),
    pytest.param(
        """
        def f(n: int) -> int:
            i = 0
            while i < n:
                i = i + 1
            return i
        """, 3, 5, "needs at least one 'invariant'", id="while-without-invariant"),
    pytest.param(
        """
        def f(a: int) -> int:
            x = a
            ensures x > 0
            return x
        """, 3, 5, "must come before the first statement", id="contract-after-statement"),
    pytest.param(
        """
        def f(n: int) -> int:
            decreases n
            decreases n + 1
            return 0
        """, 3, 5, "only one 'decreases' clause", id="two-decreases"),
    pytest.param(
        """
        def f(a: int) -> int:
            return
        """, 2, 11, "expected an expression, got end of line", id="return-without-value"),
    pytest.param(
        """
        def f(a: array) -> int:
            ensures forall k in 0 .. len(a) result >= 0
            return 0
        """, 2, 37, "expected ':' after the quantifier range", id="forall-missing-colon"),
    pytest.param(
        """
        def f(a: array) -> int:
            ensures forall k in 0, len(a): result >= 0
            return 0
        """, 2, 26, "expected '..' in the range", id="forall-bad-range"),
    pytest.param(
        """
        def f(a: array) -> int:
            return a[0)
        """, 2, 15, "expected ']', got ')'", id="mismatched-bracket"),
    pytest.param(
        """
        def f(a: int) -> int:
            requires a > 0
        """, 1, 1, "function body must contain at least one statement", id="empty-body"),
    pytest.param(
        """
        def f(a: int) -> int:
            else:
                return a
        """, 2, 5, "'else' without a matching 'if'", id="dangling-else"),
    pytest.param(
        """
        x = 1
        """, 1, 1, "expected 'def' at top level", id="top-level-statement"),
]


@pytest.mark.parametrize("source, line, col, fragment", PARSE_ERRORS)
def test_parse_errors(source, line, col, fragment):
    with pytest.raises(ParseError) as ei:
        parse(src(source))
    err = ei.value
    assert fragment in err.message
    assert (err.line, err.col) == (line, col), str(err)


def test_error_rendering_shows_caret():
    source = "def f(a: int) -> int:\n    if a >:\n        return a\n    return 0\n"
    with pytest.raises(CompileError) as ei:
        parse(source)
    rendered = ei.value.render(source, "t.veri")
    assert rendered.splitlines() == [
        "t.veri:2:11: syntax error: expected an expression, got ':'",
        "        if a >:",
        "              ^",
    ]


def test_parse_arrays_and_forall():
    f = parse(src("""
        def f(a: array) -> array:
            requires len(a) >= 1
            ensures forall k in 0 .. len(result): forall j in k .. len(result): result[k] <= result[j]
            out = [1, 2]
            out[0] = a[len(a) - 1]
            out = append(out, -a[0])
            return out
        """)).functions[0]
    assert [A.show_expr(c) for c in f.requires] == ["len(a) >= 1"]
    (ens,) = f.ensures
    assert isinstance(ens, A.Quant) and isinstance(ens.body, A.Quant)
    assert A.show_expr(ens) == "forall k in 0 .. len(result): forall j in k .. len(result): result[k] <= result[j]"
    lit, store, app, _ = f.body
    assert isinstance(lit.value, A.ArrayLit) and len(lit.value.elems) == 2
    assert isinstance(store, A.AssignIndex) and A.show_expr(store.index) == "0"
    assert A.show_expr(store.value) == "a[len(a) - 1]"
    assert isinstance(app.value, A.Call) and A.show_expr(app.value) == "append(out, -a[0])"
