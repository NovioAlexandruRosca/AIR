"""The logical IR that verification conditions are expressed in.

This is deliberately independent of z3: the VC generator produces these
expressions and a backend translates them (see `veri.backends`). Nodes are
immutable, so substitution builds new nodes and sharing is safe.

One expression language covers ints, bools and arrays. `Label` marks a
fragment of a VC with the source clause it came from (an invariant, a branch
condition, an ensures clause, ...). It does not change the meaning: a label
stands for `orig` with its source variables replaced according to `env`.
Labels are what lets the checker explain a failure in source terms ("this
invariant breaks, in this state") instead of printing one huge formula.
"""

from __future__ import annotations

from dataclasses import dataclass, fields, replace
from typing import Callable, Mapping, Union

from .typecheck import Type

# ---- nodes ---------------------------------------------------------------


@dataclass(frozen=True)
class Const:
    value: int


@dataclass(frozen=True)
class BoolLit:
    value: bool


@dataclass(frozen=True)
class Var:
    name: str
    type: Type


@dataclass(frozen=True)
class Neg:
    arg: "Expr"


@dataclass(frozen=True)
class Arith:
    op: str  # "+", "-", "*", "//", "%"  (// and % round towards -infinity, as in Python)
    left: "Expr"
    right: "Expr"


@dataclass(frozen=True)
class Cmp:
    op: str  # ">", ">=", "<", "<=", "==", "!="
    left: "Expr"
    right: "Expr"


@dataclass(frozen=True)
class Not:
    arg: "Expr"


@dataclass(frozen=True)
class And:
    args: tuple["Expr", ...]


@dataclass(frozen=True)
class Or:
    args: tuple["Expr", ...]


@dataclass(frozen=True)
class Implies:
    hyp: "Expr"
    concl: "Expr"


@dataclass(frozen=True)
class Iff:
    left: "Expr"
    right: "Expr"


@dataclass(frozen=True)
class Ite:
    cond: "Expr"
    then: "Expr"
    else_: "Expr"


@dataclass(frozen=True)
class ForAll:
    var: Var
    body: "Expr"


@dataclass(frozen=True)
class Exists:
    var: Var
    body: "Expr"


# Arrays are finite int sequences with a length (value semantics). How they are
# represented is the backend's business; these are their abstract operations.


@dataclass(frozen=True)
class ArrEmpty:
    pass


@dataclass(frozen=True)
class ArrLen:
    arr: "Expr"


@dataclass(frozen=True)
class ArrSelect:
    arr: "Expr"
    index: "Expr"


@dataclass(frozen=True)
class ArrStore:
    """`arr` with element `index` replaced by `value`; the length is unchanged."""

    arr: "Expr"
    index: "Expr"
    value: "Expr"


@dataclass(frozen=True)
class ArrAppend:
    """`arr` extended by one element: length + 1, new last element `value`."""

    arr: "Expr"
    value: "Expr"


@dataclass(frozen=True)
class Label:
    """A VC fragment that came from one source clause.

    Means `orig[env]`: `orig` is the clause over source-level variable names, and
    `env` maps those names to their value at this point in the VC (only names
    whose value differs from the same-named VC variable are listed)."""

    text: str  # e.g. "invariant (line 20): forall p in 1 .. len(out): out[p - 1] <= out[p]"
    kind: str  # "requires", "ensures", "invariant", "branch", "loop-cond", "safety", "call-pre", ...
    orig: "Expr"
    env: tuple[tuple[str, "Expr"], ...] = ()


Expr = Union[Const, BoolLit, Var, Neg, Arith, Cmp, Not, And, Or, Implies, Iff, Ite, ForAll, Exists,
             ArrEmpty, ArrLen, ArrSelect, ArrStore, ArrAppend, Label]
NODES = (Const, BoolLit, Var, Neg, Arith, Cmp, Not, And, Or, Implies, Iff, Ite, ForAll, Exists,
         ArrEmpty, ArrLen, ArrSelect, ArrStore, ArrAppend, Label)
Formula = Expr  # an Expr of type bool
Term = Expr

TRUE = BoolLit(True)
FALSE = BoolLit(False)

NEGATED_CMP = {">": "<=", ">=": "<", "<": ">=", "<=": ">", "==": "!=", "!=": "=="}

# ---- smart constructors (light, purely syntactic simplification) ---------


def mk_and(*args: Expr) -> Expr:
    flat: list[Expr] = []
    for a in args:
        if isinstance(a, And):
            flat.extend(a.args)
        elif a == TRUE:
            continue
        elif a == FALSE:
            return FALSE
        else:
            flat.append(a)
    if not flat:
        return TRUE
    return flat[0] if len(flat) == 1 else And(tuple(flat))


def mk_or(*args: Expr) -> Expr:
    flat: list[Expr] = []
    for a in args:
        if isinstance(a, Or):
            flat.extend(a.args)
        elif a == FALSE:
            continue
        elif a == TRUE:
            return TRUE
        else:
            flat.append(a)
    if not flat:
        return FALSE
    return flat[0] if len(flat) == 1 else Or(tuple(flat))


def mk_not(a: Expr) -> Expr:
    if isinstance(a, BoolLit):
        return BoolLit(not a.value)
    if isinstance(a, Cmp):
        return Cmp(NEGATED_CMP[a.op], a.left, a.right)
    if isinstance(a, Not):
        return a.arg
    return Not(a)


def mk_implies(hyp: Expr, concl: Expr) -> Expr:
    if hyp == TRUE or concl == TRUE:
        return concl
    if hyp == FALSE:
        return TRUE
    return Implies(hyp, concl)


# ---- traversal -----------------------------------------------------------


def children(e: Expr) -> list[Expr]:
    """Direct sub-expressions (a label's children are its env values; quantifier: the body)."""
    if isinstance(e, Label):
        return [v for _, v in e.env]
    if isinstance(e, (ForAll, Exists)):
        return [e.body]
    out: list[Expr] = []
    for f in fields(e):
        v = getattr(e, f.name)
        if isinstance(v, NODES):
            out.append(v)
        elif isinstance(v, tuple):
            out.extend(x for x in v if isinstance(x, NODES))
    return out


def map_children(e: Expr, fn: Callable[[Expr], Expr]) -> Expr:
    """Rebuild a non-binding, non-label node with `fn` applied to each child."""
    changes = {}
    for f in fields(e):
        v = getattr(e, f.name)
        if isinstance(v, NODES):
            changes[f.name] = fn(v)
        elif isinstance(v, tuple) and v and isinstance(v[0], NODES):
            changes[f.name] = tuple(fn(x) for x in v)
    return replace(e, **changes) if changes else e


def free_vars(e: Expr, acc: dict[str, Var] | None = None) -> dict[str, Var]:
    """Free variables, in first-occurrence order."""
    acc = {} if acc is None else acc
    if isinstance(e, Var):
        acc.setdefault(e.name, e)
    elif isinstance(e, (ForAll, Exists)):
        for k, v in free_vars(e.body).items():
            if k != e.var.name:
                acc.setdefault(k, v)
    elif isinstance(e, Label):
        env = dict(e.env)
        for k, v in free_vars(e.orig).items():
            if k in env:
                free_vars(env[k], acc)
            else:
                acc.setdefault(k, v)
    else:
        for c in children(e):
            free_vars(c, acc)
    return acc


def substitute(e: Expr, m: Mapping[str, Expr]) -> Expr:
    """Simultaneous, capture-avoiding substitution of variables by expressions: e[x1 := t1, ...]."""
    if not m:
        return e
    if isinstance(e, Var):
        return m.get(e.name, e)
    if isinstance(e, Label):
        env = dict(e.env)
        new_env = {k: substitute(v, m) for k, v in env.items()}
        for k in free_vars(e.orig):
            if k not in env and k in m:
                new_env[k] = m[k]
        return Label(e.text, e.kind, e.orig, tuple(sorted(new_env.items())))
    if isinstance(e, (ForAll, Exists)):
        body_fv = free_vars(e.body)
        m2 = {k: v for k, v in m.items() if k != e.var.name and k in body_fv}
        if not m2:
            return e
        var, body = e.var, e.body
        incoming: set[str] = set()
        for v in m2.values():
            incoming |= set(free_vars(v))
        if var.name in incoming:  # rename the bound variable to avoid capture
            taken = incoming | set(body_fv)
            new = var.name + "'"
            while new in taken:
                new += "'"
            body = substitute(body, {var.name: Var(new, var.type)})
            var = Var(new, var.type)
        return type(e)(var, substitute(body, m2))
    return map_children(e, lambda c: substitute(c, m))


def semantics(label: Label) -> Expr:
    """The formula a label stands for."""
    return substitute(label.orig, dict(label.env))


def strip_labels(e: Expr) -> Expr:
    if isinstance(e, Label):
        return strip_labels(semantics(e))
    if isinstance(e, (ForAll, Exists)):
        return type(e)(e.var, strip_labels(e.body))
    return map_children(e, strip_labels)


def bound_vars(e: Expr, acc: dict[str, Var] | None = None) -> dict[str, Var]:
    """Variables bound by a quantifier anywhere in `e` (labels included)."""
    acc = {} if acc is None else acc
    if isinstance(e, (ForAll, Exists)):
        acc.setdefault(e.var.name, e.var)
        bound_vars(e.body, acc)
    elif isinstance(e, Label):
        bound_vars(e.orig, acc)
    else:
        for c in children(e):
            bound_vars(c, acc)
    return acc


# ---- pretty printing -----------------------------------------------------

_PREC = {"quant": 0, "iff": 1, "implies": 2, "or": 3, "and": 4, "not": 5, "cmp": 6,
         "+": 7, "-": 7, "*": 8, "//": 8, "%": 8, "neg": 9, "postfix": 10}


def show(e: Expr, parent: int = 0) -> str:
    """Readable rendering in the source language's syntax."""
    if isinstance(e, Label):
        return show(semantics(e), parent)
    if isinstance(e, Const):
        return str(e.value) if e.value >= 0 or parent < _PREC["neg"] else f"({e.value})"
    if isinstance(e, BoolLit):
        return "True" if e.value else "False"
    if isinstance(e, Var):
        return e.name
    if isinstance(e, ArrEmpty):
        return "[]"
    if isinstance(e, ArrLen):
        return f"len({show(e.arr)})"
    if isinstance(e, ArrSelect):
        return f"{show(e.arr, _PREC['postfix'])}[{show(e.index)}]"
    if isinstance(e, ArrStore):
        return f"{show(e.arr, _PREC['postfix'])}[{show(e.index)} := {show(e.value)}]"
    if isinstance(e, ArrAppend):
        return f"append({show(e.arr)}, {show(e.value)})"
    if isinstance(e, Ite):
        s = f"{show(e.then, 1)} if {show(e.cond, 1)} else {show(e.else_, 1)}"
        return f"({s})" if parent > 0 else s
    if isinstance(e, (ForAll, Exists)):
        kw = "forall" if isinstance(e, ForAll) else "exists"
        s = f"{kw} {e.var.name} :: {show(e.body)}"
        return f"({s})" if parent > 0 else s
    if isinstance(e, Neg):
        return _paren(f"-{show(e.arg, _PREC['neg'])}", _PREC["neg"], parent)
    if isinstance(e, Not):
        return _paren(f"not {show(e.arg, _PREC['not'] + 1)}", _PREC["not"], parent)
    if isinstance(e, Arith):
        p = _PREC[e.op]
        return _paren(f"{show(e.left, p)} {e.op} {show(e.right, p + 1)}", p, parent)
    if isinstance(e, Cmp):
        p = _PREC["cmp"]
        return _paren(f"{show(e.left, p + 1)} {e.op} {show(e.right, p + 1)}", p, parent)
    if isinstance(e, (And, Or)):
        p = _PREC["and" if isinstance(e, And) else "or"]
        op = " and " if isinstance(e, And) else " or "
        return _paren(op.join(show(a, p + 1) for a in e.args), p, parent)
    if isinstance(e, Implies):
        # Parenthesise conjunctive hypotheses and nested implications for readability.
        p = _PREC["implies"]
        return _paren(f"{show(e.hyp, _PREC['and'] + 1)} ==> {show(e.concl, p + 1)}", p, parent)
    if isinstance(e, Iff):
        p = _PREC["iff"]
        return _paren(f"{show(e.left, p + 1)} <==> {show(e.right, p + 1)}", p, parent)
    raise TypeError(e)


def _paren(s: str, prec: int, parent: int) -> str:
    return f"({s})" if prec < parent else s


def conjuncts(e: Expr) -> list[Expr]:
    return list(e.args) if isinstance(e, And) else [e]


def outline(e: Expr, indent: str = "") -> list[str]:
    """A VC as nested 'assume ... / prove ...' lines, using the labels' source text."""
    def text(x: Expr) -> str:
        return x.text if isinstance(x, Label) else show(x)

    if isinstance(e, Implies):
        lines = [f"{indent}assume {text(h)}" for h in conjuncts(e.hyp) if not (isinstance(h, Label) and h.kind == "wf")]
        return lines + outline(e.concl, indent)
    if isinstance(e, And):
        out: list[str] = []
        for k, a in enumerate(e.args, 1):
            if isinstance(a, Implies):
                out.append(f"{indent}case {k}:")
                out.extend(outline(a, indent + "  "))
            else:
                out.extend(outline(a, indent))
        return out
    return [f"{indent}prove  {text(e)}"]
