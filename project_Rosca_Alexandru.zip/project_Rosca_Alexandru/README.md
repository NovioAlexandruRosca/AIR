# veri: a small verifiable language checked with z3

veri turns functions with `requires` / `ensures` / `invariant` / `decreases`
contracts into verification conditions and **checks them with z3**. When a check
fails, it explains the counterexample in terms of the source program. It can
also write the checks out as a standalone Python script.

```python
def max3_strict_compare(a: int, b: int, c: int) -> int:
    ensures result >= a and result >= b and result >= c
    ensures result == a or result == b or result == c
    if a > b and a > c:
        return a
    elif b > a and b > c:
        return b
    else:
        return c
```

The full language definition, EBNF grammar and VC rules are in
[docs/SPEC.md](docs/SPEC.md).

**Language at a glance:**

* types `int`, `bool`, `array` (int sequences with value semantics);
* `and or not ==> <==>` (also `&& || !`), chained comparisons `0 <= i < n`,
  `+ - * // %` (with Python semantics), `abs min max len append`;
* `forall` / `exists` over integer ranges in contracts;
* `if/elif/else`, `while` with invariants;
* function calls, including (mutual) recursion with a `decreases` measure.

## Install

Requires Python ≥ 3.10. Tested with Python 3.11.4 and `z3-solver==5.1.0.0`.

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows; on Linux/macOS: source .venv/bin/activate
pip install -e ".[test]"
```

This installs `z3-solver` (the only runtime dependency) and `pytest`, and adds a
`veri` command.

## Use

```bash
python -m veri compile examples/max3_strict_compare.veri          # check with z3 now, explain failures
python -m veri compile examples/max3.veri -o max3_new.py          # same, and also write a standalone script
python max3_new.py                                                # run that script later (needs only z3-solver)
python -m veri verify examples/max2_buggy.veri                    # same check, one line per VC
python -m veri vcs examples/sum.veri                              # print each VC as an assume/prove outline
python -m veri check examples/max3.veri                           # parse + type-check only
```

`veri <command> ...` works the same as `python -m veri <command> ...`.

`compile` builds every VC as a z3 expression in-process. For each VC it asks z3
whether `Not(VC)` is satisfiable: `unsat` means verified, `sat` means z3 found a
counterexample, `unknown` means inconclusive. Each failure is explained like this:

```
  [FAILED]       ensures result >= a and result >= b and result >= c  (line 11)
      z3: Not(VC) is sat, so the VC can be violated
      counterexample:
        a = 0, b = 0, c = -1                  (parameter)
      assuming:
        if (line 13) is false: a > b and a > c
        elif (line 15) is false: b > a and b > c
      this does not hold:
        ensures (line 11): result >= a and result >= b and result >= c
          where result = -1, a = 0, b = 0, c = -1
          result >= a   is   -1 >= 0   which is false
          result >= b   is   -1 >= 0   which is false
```

Options:

* `--brief`: one line per VC;
* `--show-z3`: also print each VC as the z3 term given to the solver;
* `--raw`: also print z3's raw model;
* `--timeout MS`: z3 timeout per VC (default 10000).

The script written with `-o` contains the same checking code
(`veri/backends/z3runtime.py`) and accepts `--brief`, `--show-z3` and `--raw`.
The exit status is 0 when everything is verified, 1 when a VC fails, and 2 when
a VC is inconclusive.

## Examples

| file | content | result |
|---|---|---|
| [max2.veri](examples/max2.veri) | max of two | 3/3 verified |
| [max2_buggy.veri](examples/max2_buggy.veri) | max2 with a flipped comparison | 2 failed |
| [max3.veri](examples/max3.veri) | max3 via two calls to max2 | 4/4 verified |
| [max3_strict_compare.veri](examples/max3_strict_compare.veri) | `if a > b and a > c ... elif b > a and b > c ... else c` | fails: tie `a == b > c` returns `c` |
| [max3_nonstrict_compare.veri](examples/max3_nonstrict_compare.veri) | the same with `>=` | 2/2 verified |
| [sum.veri](examples/sum.veri) | loops: `sum_to(n)` proves `2*result == n*(n+1)`; `count_to(n)` | 6/6 verified |
| [operators.veri](examples/operators.veri) | `abs`, `min`/`max`, `%`, bool results, `<==>`, `exists` | 12/12 verified |
| [recursion.veri](examples/recursion.veri) | recursive `sum_rec`, mutually recursive `is_even`/`is_odd` | 9/9 verified |
| [recursion_bugs.veri](examples/recursion_bugs.veri) | recursion on `n - 2` (fails precondition, termination and ensures); infinite recursion (fails termination only) | 4 failed |
| [stalin_sort_keep_running_max.veri](examples/stalin_sort_keep_running_max.veri) | Stalin sort; output sorted, no longer than input, last = max, first kept | 7/7 verified |
| [stalin_sort_compare_previous_input.veri](examples/stalin_sort_compare_previous_input.veri) | buggy Stalin sort comparing with the previous *input* element | preservation fails on `a = [0, -1, -1]` |

Standalone scripts for every example are in
[examples/generated/](examples/generated/). A test fails if they are out of date.
To regenerate one:

```bash
python -m veri compile examples/max2.veri -o examples/generated/max2.py
```

## Layout

```
veri/
  lexer.py       stage 1: tokens, INDENT/DEDENT
  astnodes.py    AST dataclasses (one expression syntax for int/bool/array)
  parser.py      stage 2: recursive-descent parser (precedence climbing for expressions)
  typecheck.py   stage 3: types (int, bool, array), builtins, calls, recursion detection,
                 scoping, definite assignment, all-paths-return
  logic.py       backend-neutral VC IR: expressions, labels, capture-avoiding substitution, printing
  vcgen.py       stage 4: weakest preconditions + safety/call/termination checks -> logic IR (no z3)
  backends/      stage 5:
    z3tree.py      IR -> VC tree (shared by both z3 paths)
    z3api.py       builds trees from live z3 objects and checks them now (veri compile)
    z3py.py        emits the standalone script (veri compile -o)
    z3runtime.py   the checking + explanation code both use (embedded verbatim in scripts)
  driver.py      pipeline glue
  cli.py         command line
tests/           pytest suite: lexer, parser (incl. error line/col), type checker, VC gen, end-to-end
```

Extension points:

* **New backend** (for example SMT-LIB): consume `vcgen.FunctionVCs` / `logic` IR,
  and register an emitter in `veri/backends/__init__.py`.
* **New type** (for example `str`): register it in `typecheck.TYPES` and its operator
  tables, and map it to a z3 sort in `backends/z3api.Z3_CONST` and `backends/z3py.Z3_DECL`.

## Tests

```bash
python -m pytest
```
