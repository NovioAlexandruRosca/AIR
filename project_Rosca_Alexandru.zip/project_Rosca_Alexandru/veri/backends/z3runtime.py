"""Checking runtime shared by both z3 paths.

* `veri compile` builds the VC trees from live z3 objects in-process
  (`z3api.py`) and checks them with the functions below.
* The standalone script written by `compile -o FILE.py` (`z3py.py`) embeds
  the source text of this module below the marker line, so it needs nothing
  but `z3-solver`.

For every VC: create a `Solver`, add `Not(vc)`, call `check()`. `unsat` means
verified, `sat` means violated, `unknown` is inconclusive. On `sat` the model
is turned into an explanation in source terms: the counterexample values, the
assumptions on the failing path, and which clause breaks, with the state at
that point and (for a failing `forall`) the concrete index where it fails.

A VC is given as a tree (see `veri/backends/z3tree.py` for the format).
"""
# ---- embedded in generated scripts from here on ----
import sys

from z3 import (And, ArraySort, Bool, BoolVal, Const, Datatype, Exists, ForAll, If, Implies, Int, IntSort, IntVal,
                K, Not, Or, Select, Solver, Store, is_false, is_int_value, is_true, sat, substitute, unknown, unsat)

TIMEOUT_MS = 10000
SMALL_BOUNDS = ((3, 3), (5, 3), (5, 5), (10, 10), (20, 20), (100, 100))  # (max array length, max |value|)
SMALL_TIMEOUT_MS = 2000
MAX_SHOWN = 20

# ---- value encodings -------------------------------------------------------

# array = finite sequence of ints: contents (total map Int -> Int) + length
IntArray = Datatype("IntArray")
IntArray.declare("mk_array", ("data", ArraySort(IntSort(), IntSort())), ("length", IntSort()))
IntArray = IntArray.create()
EMPTY_ARRAY = IntArray.mk_array(K(IntSort(), IntVal(0)), IntVal(0))


def array_store(a, i, v):
    return IntArray.mk_array(Store(IntArray.data(a), i, v), IntArray.length(a))


def array_append(a, v):
    return IntArray.mk_array(Store(IntArray.data(a), IntArray.length(a), v), IntArray.length(a) + 1)


def py_div(a, b):
    """Python's a // b (rounds towards -infinity); z3's `/` on ints is Euclidean (remainder >= 0)."""
    return If(And(b < 0, a % b != 0), a / b - 1, a / b)


def py_mod(a, b):
    """Python's a % b (takes the sign of b); z3's `%` is always >= 0."""
    return If(And(b < 0, a % b != 0), a % b + b, a % b)


CMP = {"<": lambda a, b: a < b, "<=": lambda a, b: a <= b, ">": lambda a, b: a > b,
       ">=": lambda a, b: a >= b, "==": lambda a, b: a == b, "!=": lambda a, b: a != b}

# ---- tree -> z3 formula ----------------------------------------------------


def build(t):
    kind = t[0]
    if kind == "and":
        return And(*[build(c) for c in t[2]])
    if kind == "or":
        return Or(*[build(c) for c in t[2]])
    if kind == "not":
        return Not(build(t[2]))
    if kind == "implies":
        return Implies(build(t[2]), build(t[3]))
    if kind == "iff":
        return build(t[2]) == build(t[3])
    if kind == "forall":
        return ForAll([t[2]], build(t[3]))
    if kind == "exists":
        return Exists([t[2]], build(t[3]))
    if kind == "cmp":
        return CMP[t[2]](t[3], t[4])
    if kind == "atom":
        return t[2]
    if kind == "label":
        pairs = [(var, value) for _, var, value in t[4] if not var.eq(value)]
        return substitute(build(t[3]), *pairs) if pairs else build(t[3])
    raise ValueError(kind)


# ---- models -> readable values ---------------------------------------------


def _value(m, term):
    """The value of a (possibly ground) term in model m, as a Python int, bool or list."""
    if term.sort() == IntArray:
        n = m.eval(IntArray.length(term), model_completion=True).as_long()
        shown = [_value(m, Select(IntArray.data(term), IntVal(i))) for i in range(max(0, min(n, MAX_SHOWN)))]
        return shown + ["..."] if n > MAX_SHOWN else shown
    x = m.eval(term, model_completion=True)
    if is_int_value(x):
        return x.as_long()
    if is_true(x) or is_false(x):
        return is_true(x)
    return str(x)


def _small(v, n_max, b):
    """Constraints keeping variable v small: ints in [-b, b], arrays of length <= n_max with such elements."""
    if v.sort() == IntArray:
        j = Int("j!small")
        n, d = IntArray.length(v), IntArray.data(v)
        return [n <= n_max, ForAll([j], Implies(And(0 <= j, j < n), And(-b <= Select(d, j), Select(d, j) <= b)))]
    if v.sort() == IntSort():
        return [-max(b, n_max) <= v, v <= max(b, n_max)]
    return []


def _small_model(s, consts):
    """Prefer a counterexample with small values: retry under increasing bounds, else keep z3's model."""
    model = s.model()
    s.set("timeout", SMALL_TIMEOUT_MS)
    for n_max, b in SMALL_BOUNDS:
        s.push()
        for v in consts:
            s.add(*_small(v, n_max, b))
        found = s.check() == sat
        if found:
            model = s.model()
        s.pop()
        if found:
            break
    return model


# ---- explaining a counterexample -------------------------------------------


def _ground(e, fixed):
    return substitute(e, *fixed) if fixed else e


def _truth(t, m, fixed):
    """Is tree t true in model m? Decided by evaluation, or by z3 when quantifiers are involved."""
    f = _ground(build(t), fixed)
    v = m.eval(f, model_completion=True)
    if is_true(v):
        return True
    if is_false(v):
        return False
    s = Solver()
    s.set("timeout", SMALL_TIMEOUT_MS)
    s.add(Not(f))
    for c, val in _model_pairs(m):
        s.add(c == val)
    r = s.check()
    return True if r == unsat else False if r == sat else None


def _model_pairs(m):
    return [(d(), m[d]) for d in m.decls() if d.arity() == 0]


def _conjuncts(t):
    if t[0] == "and" and not t[1]:
        out = []
        for c in t[2]:
            out.extend(_conjuncts(c))
        return out
    return [t]


def _failing_path(t, m, assumed, failed):
    """Walk a VC that is false in m: collect the hypotheses on the way and the goals that fail."""
    if t[0] == "implies" and not t[1]:
        assumed.extend(_conjuncts(t[2]))
        _failing_path(t[3], m, assumed, failed)
    elif t[0] == "and" and not t[1]:
        for c in t[2]:
            if _truth(c, m, []) is not True:
                _failing_path(c, m, assumed, failed)
    else:
        failed.append(t)


def _describe(t):
    if t[0] == "label":
        return t[1]
    if t[0] == "implies" and not t[1]:
        return f"if {_describe(t[2])} then {_describe(t[3])}"
    if t[0] == "and" and not t[1]:
        return "; ".join(_describe(c) for c in t[2])
    return t[1] or "(condition)"


def _why(t, m, fixed, out, indent):
    """Explain why tree t (its source variables fixed to values) is false."""
    pad = " " * indent
    kind = t[0]
    if kind == "forall":
        var, body = t[2], t[3]
        s = Solver()
        s.set("timeout", SMALL_TIMEOUT_MS)
        s.add(Not(_ground(build(body), fixed)))
        if s.check() == sat:
            w = s.model().eval(var, model_completion=True)
            out.append(f"{pad}fails for {var} = {_value(m, w)}:")
            _why(body, m, fixed + [(var, w)], out, indent + 2)
        else:
            out.append(f"{pad}{t[1]} is false")
    elif kind == "implies":
        _why(t[3], m, fixed, out, indent)  # the hypothesis holds, the conclusion does not
    elif kind == "and":
        for c in t[2]:
            if _truth(c, m, fixed) is not True:
                _why(c, m, fixed, out, indent)
    elif kind == "or":
        out.append(f"{pad}none of these holds:")
        for c in t[2]:
            _why(c, m, fixed, out, indent + 2)
    elif kind == "not":
        out.append(f"{pad}{t[2][1]} holds, but it must not")
    elif kind == "exists":
        out.append(f"{pad}no {t[2]} in the range makes it true")
    elif kind == "cmp":
        lhs, rhs = _value(m, _ground(t[3], fixed)), _value(m, _ground(t[4], fixed))
        out.append(f"{pad}{t[1]}   is   {lhs} {t[2]} {rhs}   which is false")
    elif kind == "iff":
        a, b = _value(m, _ground(build(t[2]), fixed)), _value(m, _ground(build(t[3]), fixed))
        out.append(f"{pad}{t[1]}   is   {a} <==> {b}   which is false")
    elif kind == "label":
        _explain_label(t, m, fixed, out, indent)
    else:
        out.append(f"{pad}{t[1]}   is false")


def _explain_label(t, m, fixed, out, indent):
    pad = " " * indent
    out.append(f"{pad}{t[1]}")
    values = [(name, var, m.eval(_ground(value, fixed), model_completion=True)) for name, var, value in t[4]]
    if values:
        intro = "with the call's arguments" if t[2] in ("call-pre", "call-post") else "where"
        out.append(f"{pad}  {intro} " + ", ".join(f"{name} = {_value(m, val)}" for name, _, val in values))
    _why(t[3], m, [(var, val) for _, var, val in values], out, indent + 2)


def explain(tree, m, variables):
    """Lines explaining, in source terms, why the VC `tree` is false in model m."""
    out = ["      counterexample:"]
    groups = {}
    for const, display, desc in variables:
        groups.setdefault(desc, []).append(f"{display} = {_value(m, const)}")
    for desc, items in groups.items():
        line = ", ".join(items)
        out.append(f"        {line:<36}  ({desc})" if desc else f"        {line}")
    assumed, failed = [], []
    _failing_path(tree, m, assumed, failed)
    shown = [h for h in assumed if not (h[0] == "label" and h[2] == "wf")]
    if shown:
        out.append("      assuming:")
        out.extend(f"        {_describe(h)}" for h in shown)
    out.append("      this does not hold:" if len(failed) == 1 else "      these do not hold:")
    for f in failed:
        _why(f, m, [], out, 8)
    return out


# ---- checking ----------------------------------------------------------------


def check_vc(function, name, line, tree, variables, verbose=True, details=False, show_z3=False, raw=False):
    """Check that the VC is valid: assert its negation and ask z3 for a model.

    `variables` lists (z3 constant, display name, description) for each free variable."""
    vc = build(tree)
    consts = [c for c, _, _ in variables]
    s = Solver()
    s.set("timeout", TIMEOUT_MS)
    s.add(Not(vc))
    r = s.check()
    result = {"function": function, "vc": name, "line": line, "check": str(r),
              "counterexample": None, "model": None, "reason": None, "explanation": None}
    if r == unsat:
        result["status"] = "verified"
    elif r == sat:
        m = _small_model(s, consts)
        result["status"] = "failed"
        result["model"] = str(m)
        result["counterexample"] = {str(c): _value(m, c) for c in consts}
        if details:
            result["explanation"] = explain(tree, m, variables)
    else:
        result["status"] = "unknown"
        result["reason"] = s.reason_unknown()
    if verbose:
        tag = {"verified": "[verified]    ", "failed": "[FAILED]      ", "unknown": "[INCONCLUSIVE]"}
        print(f"  {tag[result['status']]} {name}  (line {line})")
        if show_z3:
            print("      VC as given to z3 (it checks Not(VC)):")
            print("        " + vc.sexpr().replace("\n", "\n        "))
        if r == sat:
            if details:
                print("      z3: Not(VC) is sat, so the VC can be violated")
                print("\n".join(result["explanation"]))
            else:
                cex = ", ".join(f"{k} = {v}" for k, v in result["counterexample"].items())
                print(f"                 counterexample: {cex or '(any values)'}")
            if raw:
                print("      raw z3 model: " + result["model"].replace("\n", "\n                    "))
        elif r == unknown:
            print(f"      z3 returned unknown: {result['reason']}")
    return result


def verify_all(functions, verbose=True, details=False, show_z3=False, raw=False):
    """Check every VC of every function.

    `functions` is a list of (name, line, make_vcs); make_vcs() returns a list of
    (vc name, line, tree, variables). Returns per-VC result dicts."""
    results = []
    if verbose and details:
        print("Each VC is checked by asking z3 whether Not(VC) is satisfiable:")
        print("unsat = the VC holds for all values (verified); sat = z3 found a counterexample (failed).")
        print()
    for fname, fline, make_vcs in functions:
        if verbose:
            print(f"function {fname} (line {fline})")
        rs = [check_vc(fname, name, line, tree, variables, verbose, details, show_z3, raw)
              for name, line, tree, variables in make_vcs()]
        results.extend(rs)
        if verbose:
            n_ok = sum(r["status"] == "verified" for r in rs)
            n_bad = sum(r["status"] == "failed" for r in rs)
            n_unk = sum(r["status"] == "unknown" for r in rs)
            verdict = "VERIFIED" if n_ok == len(rs) else ("FAILED" if n_bad else "INCONCLUSIVE")
            print(f"  summary: {n_ok} verified, {n_bad} failed, {n_unk} inconclusive"
                  f" of {len(rs)} VCs -> {verdict}")
            print()
    return results


def report(results):
    """Print the overall total; return the exit status (0 verified, 1 failed, 2 inconclusive)."""
    n_ok = sum(r["status"] == "verified" for r in results)
    n_bad = sum(r["status"] == "failed" for r in results)
    n_unk = sum(r["status"] == "unknown" for r in results)
    print(f"total: {n_ok} verified, {n_bad} failed, {n_unk} inconclusive of {len(results)} VCs")
    return 1 if n_bad else (2 if n_unk else 0)


def main(functions, argv=None):
    """Entry point of generated scripts: `python script.py [--brief] [--show-z3] [--raw]`."""
    argv = sys.argv[1:] if argv is None else argv
    results = verify_all(functions, verbose=True, details="--brief" not in argv,
                         show_z3="--show-z3" in argv, raw="--raw" in argv)
    return report(results)
