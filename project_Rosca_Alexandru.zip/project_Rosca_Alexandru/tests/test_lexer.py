import pytest

from veri.errors import LexError
from veri.lexer import tokenize

from .conftest import src


def kinds(source):
    return [t.kind for t in tokenize(source)]


def test_tokens_and_positions():
    toks = tokenize("def f(a: int) -> int:\n    return a >= 10\n")
    assert [(t.kind, t.text) for t in toks[:11]] == [
        ("def", "def"), ("NAME", "f"), ("(", "("), ("NAME", "a"), (":", ":"), ("NAME", "int"),
        (")", ")"), ("->", "->"), ("NAME", "int"), (":", ":"), ("NEWLINE", ""),
    ]
    ge = next(t for t in toks if t.kind == ">=")
    assert (ge.line, ge.col) == (2, 14)
    ten = next(t for t in toks if t.kind == "INT")
    assert (ten.text, ten.line, ten.col) == ("10", 2, 17)


def test_indent_dedent_and_comments():
    s = src("""
        # comment
        def f(a: int) -> int:

            if a > 0:   # trailing comment
                return a
            return 0
        """)
    assert kinds(s) == [
        "def", "NAME", "(", "NAME", ":", "NAME", ")", "->", "NAME", ":", "NEWLINE",
        "INDENT", "if", "NAME", ">", "INT", ":", "NEWLINE",
        "INDENT", "return", "NAME", "NEWLINE",
        "DEDENT", "return", "INT", "NEWLINE",
        "DEDENT", "EOF",
    ]


def test_newlines_inside_parentheses_are_ignored():
    assert kinds("x = (1 +\n     2)\n") == ["NAME", "=", "(", "INT", "+", "INT", ")", "NEWLINE", "EOF"]


@pytest.mark.parametrize(
    "source, line, col, fragment",
    [
        ("def f(a: int) -> int:\n\treturn a\n", 2, 1, "tabs are not allowed"),
        ("def f(a: int) -> int:\n    return a $ 1\n", 2, 14, "unexpected character '$'"),
        ("def f(a: int) -> int:\n    return a / 2\n", 2, 14, "use '//' for integer division"),
        ("def f(a: int) -> int:\n    return 5x\n", 2, 12, "invalid integer literal"),
        ("def f(a: int) -> int:\n    if a > 0:\n        return a\n      return 0\n", 4, 7, "unindent does not match"),
    ],
)
def test_lex_errors(source, line, col, fragment):
    with pytest.raises(LexError) as ei:
        tokenize(source)
    assert (ei.value.line, ei.value.col) == (line, col)
    assert fragment in ei.value.message

