"""Diagnostics shared by every compiler stage."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Pos:
    """A 1-based source position."""

    line: int
    col: int

    def __str__(self) -> str:
        return f"{self.line}:{self.col}"


class CompileError(Exception):
    """An error with a source position. Raised by the lexer, parser and type checker."""

    stage = "error"

    def __init__(self, message: str, pos: Pos):
        super().__init__(message)
        self.message = message
        self.pos = pos

    @property
    def line(self) -> int:
        return self.pos.line

    @property
    def col(self) -> int:
        return self.pos.col

    def __str__(self) -> str:
        return f"{self.pos.line}:{self.pos.col}: {self.stage}: {self.message}"

    def render(self, source: str, filename: str = "<input>") -> str:
        """Format like `file:line:col: kind: message` followed by the line and a caret."""
        out = f"{filename}:{self.pos.line}:{self.pos.col}: {self.stage}: {self.message}"
        lines = source.splitlines()
        if 1 <= self.pos.line <= len(lines):
            text = lines[self.pos.line - 1]
            out += f"\n    {text}\n    {' ' * (self.pos.col - 1)}^"
        return out


class LexError(CompileError):
    stage = "syntax error"


class ParseError(CompileError):
    stage = "syntax error"


class TypeCheckError(CompileError):
    stage = "type error"
