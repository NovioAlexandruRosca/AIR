"""veri: a small verifiable language compiled to z3-checked Python."""

__version__ = "0.1.0"
