"""Stage 4: verification-condition generation by weakest preconditions.

The generator walks each function body backwards, transforming a list of
*goals* (formulas that must hold at the current program point):

* targets: what the continuation must establish. `return e` produces one
  target per `ensures` clause, Q[result := e]; the end of a loop body
  produces the target "invariant holds again".
* obligations: side conditions created along the way (loop entry /
  preservation / exit, array bounds, division by zero, callee preconditions,
  termination). They travel backwards like targets, so they are evaluated in
  the correct state, but each becomes its own VC.

The rules (Dijkstra's wp, applied to each goal):

    wp(x = e, Q)            = Q[x := e]
    wp(x[i] = e, Q)         = Q[x := x[i := e]]
    wp(return e, _)         = Post[result := e]            (continuation is dead)
    wp(if c: A else: B, Q)  = (c ==> wp(A, Q)) && (not c ==> wp(B, Q))
    wp(while c inv I: B, Q) = I                                           (entry)
        plus, with the loop-modified variables replaced by fresh ones (x@loopN):
            I && c      ==> wp(B, I)                                      (preservation)
            I && not c  ==> Q                                             (exit)

Evaluating an expression can add *effects*, in evaluation order:

* checks: `a[i]` needs 0 <= i < len(a); `x // y` and `x % y` need y != 0;
  a call `f(args)` needs f's `requires` (and, inside a recursion cycle, that
  the `decreases` measure goes down);
* assumptions: a call `f(args)` is replaced by a fresh variable `f@callN`
  about which f's `ensures` may be assumed (modular verification: the
  callee's body is not looked at).

Each effect is guarded by the short-circuit condition under which it is
evaluated (in `i < len(a) and a[i] > 0`, the bounds check of a[i] assumes
`i < len(a)`). Contracts are specifications, not code: they produce no
effects, and an out-of-range `a[i]` there is just an unspecified integer.

Every fragment that comes from a source clause is wrapped in a `Label`, so
the checker can later explain a failure in terms of the source program.

Finally each goal becomes one VC: `well-formed && requires ==> goal`, where
well-formedness says every array variable has a non-negative length.
The output is pure `veri.logic` IR; no backend is involved here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from . import astnodes as A
from . import logic as L
from .errors import Pos
from .typecheck import ARRAY, INT, RESULT, FunctionInfo, Type, TypedProgram, assigned_names

TARGET = "target"
OBLIGATION = "obligation"

KIND_ORDER = {"ensures": 0, "safety": 1, "call-pre": 2, "termination": 3,
              "loop-entry": 4, "loop-preserve": 5, "loop-exit": 6}

#: Facts every value of a type satisfies, assumed for each free variable of a VC.
WELL_FORMED: dict[Type, Callable[[L.Var], L.Expr]] = {
    ARRAY: lambda v: L.Label(f"len({v.name}) >= 0", "wf", L.Cmp(">=", L.ArrLen(v), L.Const(0))),
}


@dataclass(frozen=True)
class Goal:
    key: str  # merge key; goals with the same key are conjoined at join points
    kind: str  # TARGET or OBLIGATION
    formula: L.Expr


@dataclass
class VC:
    """One verification condition: `formula` must be valid."""

    function: str
    name: str
    kind: str  # one of KIND_ORDER
    pos: Pos
    formula: L.Expr
    variables: list[L.Var] = field(default_factory=list)
    #: VC variable name -> (display name, description) for presenting counterexamples
    var_info: dict[str, tuple[str, str]] = field(default_factory=dict)

    def __str__(self) -> str:
        return f"[{self.function}] {self.name} (line {self.pos.line}): {L.show(self.formula)}"


@dataclass
class FunctionVCs:
    name: str
    pos: Pos
    params: list[L.Var]
    vcs: list[VC]


@dataclass
class _Meta:
    name: str
    kind: str
    pos: Pos


class Effects:
    """Checks and assumptions produced while evaluating expressions, in evaluation order."""

    def __init__(self) -> None:
        self.items: list[tuple] = []

    def check(self, key: str, formula: L.Expr) -> None:
        self.items.append(("check", key, formula))

    def assume(self, formula: L.Expr) -> None:
        self.items.append(("assume", formula))

    def split(self) -> tuple[L.Expr, list[Goal]]:
        """(all assumptions, check goals). Each check may rely on the assumptions made before it."""
        assumed: list[L.Expr] = []
        checks: list[Goal] = []
        for item in self.items:
            if item[0] == "assume":
                assumed.append(item[1])
            else:
                checks.append(Goal(item[1], OBLIGATION, L.mk_implies(L.mk_and(*assumed), item[2])))
        return L.mk_and(*assumed), checks


class Translator:
    """AST expressions -> logic IR for one function's variables (contracts only: no effects)."""

    def __init__(self, info: FunctionInfo):
        self.info = info
        self.bound: set[str] = set()  # quantified variables in scope

    def var(self, name: str) -> L.Var:
        if name in self.bound:
            return L.Var(name, INT)
        return L.Var(name, self.info.var_type(name))

    def spec(self, e: A.Expr) -> L.Expr:
        return self.expr(e, L.TRUE, None)

    def expr(self, e: A.Expr, guard: L.Expr, eff: Effects | None) -> L.Expr:
        """Translate `e`. In code (eff is not None), record checks/assumptions guarded by `guard`."""
        if isinstance(e, A.IntLit):
            return L.Const(e.value)
        if isinstance(e, A.BoolLit):
            return L.BoolLit(e.value)
        if isinstance(e, A.Name):
            return self.var(e.ident)
        if isinstance(e, A.UnaryOp):
            arg = self.expr(e.operand, guard, eff)
            return L.Neg(arg) if e.op == "-" else L.Not(arg)
        if isinstance(e, A.BinOp):
            return self.binop(e, guard, eff)
        if isinstance(e, A.Index):
            arr = self.expr(e.array, guard, eff)
            idx = self.expr(e.index, guard, eff)
            if eff is not None:
                self.safety_check(eff, guard, e, f"index in bounds: {A.show_expr(e)}",
                                  f"index {A.show_expr(e.index)} of {A.show_expr(e)} is within 0 .. len({A.show_expr(e.array)})",
                                  in_bounds(arr, idx))
            return L.ArrSelect(arr, idx)
        if isinstance(e, A.Call):
            return self.call(e, guard, eff)
        if isinstance(e, A.ArrayLit):
            arr: L.Expr = L.ArrEmpty()
            for el in e.elems:
                arr = L.ArrAppend(arr, self.expr(el, guard, eff))
            return arr
        if isinstance(e, A.Quant):
            v = L.Var(e.var, INT)
            in_range = L.And((L.Cmp("<=", self.expr(e.lo, guard, eff), v), L.Cmp("<", v, self.expr(e.hi, guard, eff))))
            self.bound.add(e.var)
            try:
                body = self.expr(e.body, guard, eff)
            finally:
                self.bound.discard(e.var)
            if e.kind == "forall":
                return L.ForAll(v, L.Implies(in_range, body))
            return L.Exists(v, L.And((in_range, body)))
        raise TypeError(e)

    def binop(self, e: A.BinOp, guard: L.Expr, eff: Effects | None) -> L.Expr:
        left = self.expr(e.left, guard, eff)
        # Short-circuit: the right operand is evaluated only when it matters.
        if e.op == "and":
            return L.And((left, self.expr(e.right, L.mk_and(guard, left), eff)))
        if e.op == "or":
            return L.Or((left, self.expr(e.right, L.mk_and(guard, L.Not(left)), eff)))
        if e.op == "==>":
            return L.Implies(left, self.expr(e.right, L.mk_and(guard, left), eff))
        right = self.expr(e.right, guard, eff)
        if e.op == "<==>":
            return L.Iff(left, right)
        if e.op in A.CMP_OPS:
            return L.Cmp(e.op, left, right)
        if e.op in ("//", "%") and eff is not None:
            self.safety_check(eff, guard, e, f"no division by zero: {A.show_expr(e)}",
                              f"divisor {A.show_expr(e.right)} of {A.show_expr(e)} is not zero",
                              L.Cmp("!=", right, L.Const(0)))
        return L.Arith(e.op, left, right)

    def call(self, e: A.Call, guard: L.Expr, eff: Effects | None) -> L.Expr:
        args = [self.expr(a, guard, eff) for a in e.args]
        if e.func == "len":
            return L.ArrLen(args[0])
        if e.func == "append":
            return L.ArrAppend(*args)
        if e.func == "abs":
            return L.Ite(L.Cmp(">=", args[0], L.Const(0)), args[0], L.Neg(args[0]))
        if e.func == "min":
            return L.Ite(L.Cmp("<=", args[0], args[1]), args[0], args[1])
        if e.func == "max":
            return L.Ite(L.Cmp(">=", args[0], args[1]), args[0], args[1])
        return self.user_call(e, args, guard, eff)

    def user_call(self, e: A.Call, args: list[L.Expr], guard: L.Expr, eff: Effects | None) -> L.Expr:
        raise TypeError("user-defined calls only occur in code")  # overridden by FunctionVCGen

    def safety_check(self, eff, guard, e, name, text, formula) -> None:
        raise TypeError("safety checks only occur in code")  # overridden by FunctionVCGen


def in_bounds(arr: L.Expr, idx: L.Expr) -> L.Expr:
    return L.And((L.Cmp("<=", L.Const(0), idx), L.Cmp("<", idx, L.ArrLen(arr))))


class FunctionVCGen(Translator):
    def __init__(self, info: FunctionInfo, program: dict[str, FunctionInfo]):
        super().__init__(info)
        self.func = info.func
        self.program = program
        self.meta: dict[str, _Meta] = {}
        self.used_names: set[str] = set(info.param_types) | set(info.local_types) | {RESULT}
        self.var_info: dict[str, tuple[str, str]] = {p: (p, "parameter") for p in info.param_types}
        self.post: list[tuple[str, L.Expr]] = []
        for k, clause in enumerate(self.func.ensures):
            key = f"ensures#{k}"
            self.meta[key] = _Meta(f"ensures {A.show_expr(clause)}", "ensures", clause.pos)
            self.post.append((key, self.label("ensures", clause, self.spec(clause))))

    # ---- helpers ---------------------------------------------------------

    @staticmethod
    def label(what: str, clause: A.Expr, orig: L.Expr, kind: str | None = None, suffix: str = "") -> L.Label:
        return L.Label(f"{what} (line {clause.pos.line}){suffix}: {A.show_expr(clause)}", kind or what, orig)

    def fresh(self, base: str) -> str:
        cand, k = base, 2
        while cand in self.used_names:
            cand, k = f"{base}_{k}", k + 1
        self.used_names.add(cand)
        return cand

    def obligation_key(self, kind: str, pos: Pos, name: str) -> str:
        key = f"{kind}@{pos.line}:{pos.col}:{name}"
        self.meta[key] = _Meta(name, kind, pos)
        return key

    def safety_check(self, eff, guard, e, name, text, formula) -> None:
        key = self.obligation_key("safety", e.pos, name)
        eff.check(key, L.mk_implies(guard, L.Label(f"{text} (line {e.pos.line})", "safety", formula)))

    def user_call(self, e: A.Call, args: list[L.Expr], guard: L.Expr, eff: Effects | None) -> L.Expr:
        callee = self.program[e.func]
        cf = callee.func
        spec = Translator(callee)
        env = tuple(sorted(zip((p.name for p in cf.params), args)))
        call_text = A.show_expr(e)

        if cf.requires:
            key = self.obligation_key("call-pre", e.pos, f"precondition of {cf.name} holds for {call_text}")
            pre = L.mk_and(*(L.Label(f"requires of {cf.name} (line {r.pos.line}) for {call_text}: {A.show_expr(r)}",
                                     "call-pre", spec.spec(r), env) for r in cf.requires))
            eff.check(key, L.mk_implies(guard, pre))

        if e.func in self.info.recursive_group:
            key = self.obligation_key("termination", e.pos, f"termination: {call_text} decreases the measure")
            mine, theirs = self.func.decreases, cf.decreases
            m_here = self.spec(mine)
            m_call = L.substitute(spec.spec(theirs), dict(env))
            text = (f"decreases (line {mine.pos.line}): for the call {call_text}, "
                    f"{cf.name}'s measure {A.show_expr(theirs)} must be >= 0 and smaller than {A.show_expr(mine)}")
            formula = L.And((L.Cmp("<=", L.Const(0), m_call), L.Cmp("<", m_call, m_here)))
            eff.check(key, L.mk_implies(guard, L.Label(text, "termination", formula)))

        r = L.Var(self.fresh(f"{cf.name}@call{e.pos.line}"), callee.return_type)
        self.var_info[r.name] = (call_text, f"value returned by the call at line {e.pos.line}")
        if cf.ensures:
            post_env = tuple(sorted(env + ((RESULT, r),)))
            post = L.mk_and(*(L.Label(f"{call_text} (line {e.pos.line}) satisfies {cf.name}'s ensures "
                                      f"(line {c.pos.line}): {A.show_expr(c)}", "call-post", spec.spec(c), post_env)
                              for c in cf.ensures))
            eff.assume(L.mk_implies(guard, post))
        return r

    def code(self, e: A.Expr, eff: Effects) -> L.Expr:
        return self.expr(e, L.TRUE, eff)

    @staticmethod
    def with_effects(eff: Effects, goals: list[Goal]) -> list[Goal]:
        assumed, checks = eff.split()
        return checks + [Goal(g.key, g.kind, L.mk_implies(assumed, g.formula)) for g in goals]

    # ---- weakest preconditions -------------------------------------------

    def wp_block(self, stmts: list[A.Stmt], goals: list[Goal]) -> list[Goal]:
        for s in reversed(stmts):
            goals = self.wp_stmt(s, goals)
        return goals

    def wp_stmt(self, s: A.Stmt, goals: list[Goal]) -> list[Goal]:
        eff = Effects()
        if isinstance(s, A.Assign):
            m = {s.target: self.code(s.value, eff)}
            return self.with_effects(eff, [Goal(g.key, g.kind, L.substitute(g.formula, m)) for g in goals])

        if isinstance(s, A.AssignIndex):
            arr, idx = self.var(s.target), self.code(s.index, eff)
            value = self.code(s.value, eff)
            text = f"{s.target}[{A.show_expr(s.index)}]"
            key = self.obligation_key("safety", s.pos, f"index in bounds: {text} (write)")
            eff.check(key, L.Label(f"index {A.show_expr(s.index)} of {text} (write) is within 0 .. len({s.target}) "
                                   f"(line {s.pos.line})", "safety", in_bounds(arr, idx)))
            m = {s.target: L.ArrStore(arr, idx, value)}
            return self.with_effects(eff, [Goal(g.key, g.kind, L.substitute(g.formula, m)) for g in goals])

        if isinstance(s, A.Return):
            m = {RESULT: self.code(s.value, eff)}
            return self.with_effects(eff, [Goal(key, TARGET, L.substitute(q, m)) for key, q in self.post])

        if isinstance(s, A.If):
            c = self.code(s.cond, eff)
            yes = self.label(s.keyword, s.cond, c, "branch", " is true")
            no = self.label(s.keyword, s.cond, L.Not(c), "branch", " is false")
            then_goals = self.wp_block(s.then_body, goals)
            else_goals = self.wp_block(s.else_body, goals)
            merged: dict[str, tuple[str, list[L.Expr]]] = {}
            for guard, gs in ((yes, then_goals), (no, else_goals)):
                for g in gs:
                    merged.setdefault(g.key, (g.kind, []))[1].append(L.mk_implies(guard, g.formula))
            return self.with_effects(eff, [Goal(key, kind, L.mk_and(*fs)) for key, (kind, fs) in merged.items()])

        if isinstance(s, A.While):
            return self.wp_while(s, goals)

        raise TypeError(s)

    def wp_while(self, loop: A.While, goals: list[Goal]) -> list[Goal]:
        line = loop.pos.line
        tag = f"loop@{loop.pos.line}:{loop.pos.col}"

        def invariant(suffix: str) -> L.Expr:
            return L.mk_and(*(self.label("invariant", i, self.spec(i), suffix=suffix) for i in loop.invariants))

        cond_eff = Effects()
        c = self.code(loop.cond, cond_eff)
        cond_assumed, cond_checks = cond_eff.split()

        modified = sorted(assigned_names(loop.body))
        havoc: dict[str, L.Expr] = {}
        for x in modified:
            name = self.fresh(f"{x}@loop{line}")
            havoc[x] = L.Var(name, self.info.var_type(x))
            self.var_info[name] = (x, f"at the start of an arbitrary iteration of the loop at line {line}")

        inv_h = L.substitute(invariant(""), havoc)
        holds = L.substitute(L.mk_and(cond_assumed, self.label("loop condition", loop.cond, c, "loop-cond", " holds")),
                             havoc)
        fails = L.substitute(L.mk_and(cond_assumed, self.label("loop condition", loop.cond, L.Not(c), "loop-cond",
                                                               " is false, so the loop exits")), havoc)
        in_body, at_exit = L.mk_and(inv_h, holds), L.mk_and(inv_h, fails)

        def wrap(ctx: L.Expr, f: L.Expr) -> L.Expr:
            return L.mk_implies(ctx, L.substitute(f, havoc))

        def split(gs: list[Goal]) -> tuple[L.Expr, list[Goal]]:
            targets = L.mk_and(*(g.formula for g in gs if g.kind == TARGET))
            return targets, [g for g in gs if g.kind == OBLIGATION]

        self.meta[f"{tag}/entry"] = _Meta(f"loop at line {line}: invariant holds on entry", "loop-entry", loop.pos)
        self.meta[f"{tag}/preserve"] = _Meta(
            f"loop at line {line}: invariant is preserved by the body", "loop-preserve", loop.pos)
        self.meta[f"{tag}/exit"] = _Meta(
            f"loop at line {line}: invariant and not ({A.show_expr(loop.cond)}) imply the rest", "loop-exit", loop.pos)

        # Preservation: one arbitrary iteration starting from I && c must re-establish I
        # (or, if the body returns, establish the postcondition).
        body_goals = self.wp_block(loop.body, [Goal(f"{tag}/preserve", TARGET, invariant(" again after the body"))])
        body_targets, body_obligations = split(body_goals)
        exit_targets, later_obligations = split(goals)

        # The condition is evaluated in states satisfying I (on entry and after each iteration).
        result = [Goal(g.key, OBLIGATION, wrap(inv_h, g.formula)) for g in cond_checks]
        result.append(Goal(f"{tag}/entry", OBLIGATION, invariant(" on entry to the loop")))
        result.append(Goal(f"{tag}/preserve", OBLIGATION, wrap(in_body, body_targets)))
        result += [Goal(g.key, OBLIGATION, wrap(in_body, g.formula)) for g in body_obligations]
        result.append(Goal(f"{tag}/exit", OBLIGATION, wrap(at_exit, exit_targets)))
        result += [Goal(g.key, OBLIGATION, wrap(at_exit, g.formula)) for g in later_obligations]
        return result

    # ---- driver ----------------------------------------------------------

    def generate(self) -> FunctionVCs:
        goals = self.wp_block(self.func.body, [])
        pre = L.mk_and(*(self.label("requires", r, self.spec(r)) for r in self.func.requires))

        by_key: dict[str, list[L.Expr]] = {}
        for g in goals:
            by_key.setdefault(g.key, []).append(g.formula)
        # An ensures clause no return statement reaches (e.g. every return is
        # after a loop) is covered by that loop's exit VC.
        vcs = []
        for key, fs in by_key.items():
            m = self.meta[key]
            goal = L.mk_and(*fs)
            fv = L.free_vars(L.mk_implies(pre, goal)).values()
            wf = L.mk_and(*(WELL_FORMED[v.type](v) for v in fv if v.type in WELL_FORMED))
            formula = L.mk_implies(L.mk_and(wf, pre), goal)
            variables = self.order_vars(formula)
            info = {v.name: self.var_info.get(v.name, (v.name, "")) for v in variables}
            vcs.append(VC(self.func.name, m.name, m.kind, m.pos, formula, variables, info))
        vcs.sort(key=lambda v: (v.pos.line, v.pos.col, KIND_ORDER[v.kind]))
        params = [self.var(p.name) for p in self.func.params]
        return FunctionVCs(self.func.name, self.func.pos, params, vcs)

    def order_vars(self, f: L.Expr) -> list[L.Var]:
        """Free variables: parameters first (in declaration order), then the rest by name."""
        fv = L.free_vars(f)
        params = [fv.pop(p.name) for p in self.func.params if p.name in fv]
        return params + sorted(fv.values(), key=lambda v: v.name)


def generate(typed: TypedProgram) -> list[FunctionVCs]:
    program = typed.by_name
    return [FunctionVCGen(info, program).generate() for info in typed.functions]
