"""Stage 5: backends turn generated VCs into an executable artifact.

A backend is any object with a `name` and an
`emit(functions, source_name) -> str` method. Backends only consume
`veri.vcgen.FunctionVCs` / `veri.logic` IR, so adding one (e.g. SMT-LIB
text) does not touch the VC generator.
"""

from __future__ import annotations

from typing import Protocol

from ..vcgen import FunctionVCs
from .z3py import Z3PyBackend


class Backend(Protocol):
    name: str
    file_extension: str

    def emit(self, functions: list[FunctionVCs], source_name: str) -> str: ...


BACKENDS: dict[str, Backend] = {b.name: b for b in (Z3PyBackend(),)}
DEFAULT_BACKEND = "z3py"


def get_backend(name: str = DEFAULT_BACKEND) -> Backend:
    try:
        return BACKENDS[name]
    except KeyError:
        raise ValueError(f"unknown backend {name!r}; available: {', '.join(sorted(BACKENDS))}") from None
