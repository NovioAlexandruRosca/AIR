"""The compilation pipeline: source -> tokens -> AST -> typed AST -> VCs -> z3."""

from __future__ import annotations

from .backends import DEFAULT_BACKEND, get_backend
from .parser import parse
from .typecheck import TypedProgram, check_program
from .vcgen import FunctionVCs, generate


def check(source: str) -> TypedProgram:
    """Lex, parse and type-check. Raises `CompileError` with line and column."""
    return check_program(parse(source))


def vcs(source: str) -> list[FunctionVCs]:
    return generate(check(source))


def check_with_z3(source: str, verbose: bool = True, details: bool = False, show_z3: bool = False,
                  raw: bool = False, timeout_ms: int = 10_000) -> list[dict]:
    """Generate the VCs and send them to z3 in-process. Returns per-VC result dicts."""
    from .backends import z3api  # imported lazily: everything before this stage works without z3

    return z3api.check(vcs(source), verbose=verbose, details=details, show_z3=show_z3, raw=raw,
                       timeout_ms=timeout_ms)


def compile_source(source: str, source_name: str = "<input>", backend: str = DEFAULT_BACKEND, **opts) -> str:
    """Compile a program to the backend's output (a standalone Python script for `z3py`)."""
    b = get_backend(backend)
    if opts:
        b = type(b)(**opts)
    return b.emit(vcs(source), source_name)


def run_generated(code: str, verbose: bool = True) -> list[dict]:
    """Execute a generated z3py script in a fresh namespace and return its per-VC results."""
    namespace: dict = {"__name__": "veri_generated"}
    exec(compile(code, "<veri-generated>", "exec"), namespace)
    return namespace["verify_all"](namespace["FUNCTIONS"], verbose=verbose)
