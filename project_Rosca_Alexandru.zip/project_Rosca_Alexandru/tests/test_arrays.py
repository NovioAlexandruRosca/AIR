"""Array semantics: reads, writes, append, literals and automatic bounds VCs."""

from veri import logic as L
from veri.driver import vcs

from .conftest import src, statuses, verify


def test_unguarded_read_fails_bounds_check_on_empty_array():
    results = verify(src("""
        def first(a: array) -> int:
            return a[0]
        """))
    (r,) = results
    assert r["vc"] == "index in bounds: a[0]"
    assert r["status"] == "failed" and r["counterexample"] == {"a": []}


def test_requires_makes_read_safe():
    results = verify(src("""
        def first(a: array) -> int:
            requires len(a) >= 1
            ensures result == a[0]
            return a[0]
        """))
    assert {r["status"] for r in results} == {"verified"}


def test_element_write_and_append():
    results = verify(src("""
        def set_first(a: array) -> array:
            requires len(a) >= 1
            ensures len(result) == len(a) + 1
            ensures result[0] == 7
            ensures result[len(a)] == 8
            ensures forall k in 1 .. len(a): result[k] == a[k]
            out = a
            out[0] = 7
            out = append(out, 8)
            return out
        """))
    assert len(results) == 5  # 4 ensures + 1 write bounds check
    assert {r["status"] for r in results} == {"verified"}, results


def test_out_of_bounds_write_is_reported():
    st = statuses(verify(src("""
        def bad(a: array) -> array:
            out = a
            out[len(a)] = 1
            return out
        """)))
    assert st == {"index in bounds: out[len(a)] (write)": "failed"}


def test_array_literal():
    results = verify(src("""
        def three() -> array:
            ensures len(result) == 3
            ensures result[1] == 20
            return [10, 20, 30]
        """))
    assert {r["status"] for r in results} == {"verified"}


def test_linear_search_with_quantified_invariant():
    results = verify(src("""
        def index_of(a: array, x: int) -> int:
            ensures result <= len(a)
            ensures forall k in 0 .. result: a[k] != x
            i = 0
            while i < len(a):
                invariant i >= 0
                invariant i <= len(a)
                invariant forall k in 0 .. i: a[k] != x
                if a[i] == x:
                    return i
                i = i + 1
            return i
        """))
    assert {r["status"] for r in results} == {"verified"}, results


def test_array_lengths_are_assumed_non_negative():
    (fn,) = vcs(src("""
        def n(a: array) -> int:
            ensures result >= 0
            return len(a)
        """))
    assert L.show(fn.vcs[0].formula) == "len(a) >= 0 ==> len(a) >= 0"
