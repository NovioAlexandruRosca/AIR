"""Stage 3: type checker and static semantic checks.

Types are values in a registry and operator/builtin typing is table-driven,
so a new type (e.g. `str` backed by z3's String sort) is added by
registering it here and teaching the backend its sort; the VC generator
only sees the resulting `Type` of every variable.

Types: `int` (unbounded integers), `bool`, and `array` (finite sequences of
ints with a length, value semantics).

Besides typing, this stage enforces the rules the VC generator relies on:

* parameters are immutable (so `ensures` can refer to their input values);
* `result` may only appear in `ensures`; `requires` / `decreases` may only mention parameters;
* quantifiers only appear in contracts, and never shadow another variable;
* contracts do not call user-defined functions;
* every variable is definitely assigned before it is read;
* every path through a function ends in `return`, and no code follows a `return`;
* recursive functions (directly or mutually) have a `decreases` clause.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import astnodes as A
from .errors import Pos, TypeCheckError


@dataclass(frozen=True)
class Type:
    name: str

    def __str__(self) -> str:
        return self.name


INT = Type("int")
BOOL = Type("bool")
ARRAY = Type("array")

#: Types that can be written in source.
TYPES: dict[str, Type] = {"int": INT, "bool": BOOL, "array": ARRAY}

#: Types users may try to write that are deliberately not supported.
PLANNED_TYPES = {"str": "it is planned for a later version (z3 String sort)"}

#: (op, left type, right type) -> result type
BINARY_OPS: dict[tuple[str, Type, Type], Type] = {
    **{(op, INT, INT): INT for op in A.ARITH_OPS},
    **{(op, INT, INT): BOOL for op in A.CMP_OPS},
    ("==", BOOL, BOOL): BOOL,
    ("!=", BOOL, BOOL): BOOL,
    **{(op, BOOL, BOOL): BOOL for op in A.LOGIC_OPS},
}
UNARY_OPS: dict[tuple[str, Type], Type] = {("-", INT): INT, ("not", BOOL): BOOL}
#: name -> (parameter types, result type)
BUILTINS: dict[str, tuple[tuple[Type, ...], Type]] = {
    "len": ((ARRAY,), INT),
    "append": ((ARRAY, INT), ARRAY),
    "abs": ((INT,), INT),
    "min": ((INT, INT), INT),
    "max": ((INT, INT), INT),
}

RESULT = "result"
CONTRACTS = ("requires", "ensures", "invariant", "decreases")


@dataclass
class FunctionInfo:
    """Type information for one function, consumed by the VC generator."""

    func: A.Function
    param_types: dict[str, Type]
    return_type: Type
    local_types: dict[str, Type] = field(default_factory=dict)
    callees: set[str] = field(default_factory=set)
    #: Functions in the same recursion cycle (including itself); empty if not recursive.
    recursive_group: frozenset[str] = frozenset()

    def var_type(self, name: str) -> Type:
        if name == RESULT:
            return self.return_type
        return self.param_types.get(name) or self.local_types[name]


@dataclass
class TypedProgram:
    program: A.Program
    functions: list[FunctionInfo]

    @property
    def by_name(self) -> dict[str, FunctionInfo]:
        return {f.func.name: f for f in self.functions}


def resolve_type(ref: A.TypeRef) -> Type:
    if ref.name in TYPES:
        return TYPES[ref.name]
    if ref.name in PLANNED_TYPES:
        raise TypeCheckError(f"type '{ref.name}' is not supported: {PLANNED_TYPES[ref.name]}", ref.pos)
    raise TypeCheckError(f"unknown type '{ref.name}'", ref.pos)


def assigned_names(stmts: list[A.Stmt]) -> set[str]:
    """Variables a statement list may modify (plain or element assignment)."""
    out: set[str] = set()
    for s in stmts:
        if isinstance(s, (A.Assign, A.AssignIndex)):
            out.add(s.target)
        elif isinstance(s, A.If):
            out |= assigned_names(s.then_body) | assigned_names(s.else_body)
        elif isinstance(s, A.While):
            out |= assigned_names(s.body)
    return out


Signature = tuple[tuple[Type, ...], Type]


class FunctionChecker:
    def __init__(self, func: A.Function, signatures: dict[str, Signature]):
        self.func = func
        self.signatures = signatures
        self.params: dict[str, Type] = {}
        for p in func.params:
            if p.name in self.params:
                raise TypeCheckError(f"duplicate parameter '{p.name}'", p.pos)
            if p.name == RESULT:
                raise TypeCheckError("'result' is reserved for the return value in 'ensures'", p.pos)
            self.params[p.name] = resolve_type(p.type)
        self.info = FunctionInfo(func, self.params, resolve_type(func.return_type))
        self.all_locals = assigned_names(func.body)
        self.bound: set[str] = set()  # quantified variables currently in scope

    # ---- expressions -----------------------------------------------------

    def expr(self, e: A.Expr, scope: set[str], ctx: str) -> Type:
        if isinstance(e, A.IntLit):
            return INT
        if isinstance(e, A.BoolLit):
            return BOOL
        if isinstance(e, A.Name):
            return self.name(e, scope, ctx)
        if isinstance(e, A.UnaryOp):
            t = self.expr(e.operand, scope, ctx)
            if (e.op, t) not in UNARY_OPS:
                raise TypeCheckError(f"'{e.op}' is not defined for {t}", e.pos)
            return UNARY_OPS[(e.op, t)]
        if isinstance(e, A.BinOp):
            lt, rt = self.expr(e.left, scope, ctx), self.expr(e.right, scope, ctx)
            if (e.op, lt, rt) not in BINARY_OPS:
                if e.op in A.CMP_OPS:
                    raise TypeCheckError(f"cannot compare {lt} with {rt} using '{e.op}'", e.pos)
                raise TypeCheckError(f"operator '{e.op}' is not defined for {lt} and {rt}", e.pos)
            return BINARY_OPS[(e.op, lt, rt)]
        if isinstance(e, A.Index):
            at = self.expr(e.array, scope, ctx)
            if at != ARRAY:
                raise TypeCheckError(f"cannot index a value of type {at}", e.pos)
            self.expect(e.index, INT, scope, ctx, "an array index")
            return INT
        if isinstance(e, A.Call):
            return self.call(e, scope, ctx)
        if isinstance(e, A.ArrayLit):
            for el in e.elems:
                self.expect(el, INT, scope, ctx, "an array element")
            return ARRAY
        if isinstance(e, A.Quant):
            return self.quant(e, scope, ctx)
        raise TypeError(e)

    def call(self, e: A.Call, scope: set[str], ctx: str) -> Type:
        if e.func in BUILTINS:
            params, ret = BUILTINS[e.func]
        elif e.func in self.signatures:
            if ctx in CONTRACTS:
                raise TypeCheckError(
                    f"calls to user-defined functions are not allowed in '{ctx}' clauses", e.pos)
            params, ret = self.signatures[e.func]
            self.info.callees.add(e.func)
        else:
            raise TypeCheckError(f"unknown function '{e.func}' (builtins: {', '.join(BUILTINS)})", e.pos)
        if len(e.args) != len(params):
            raise TypeCheckError(f"{e.func}() takes {len(params)} argument(s), got {len(e.args)}", e.pos)
        for k, (arg, pt) in enumerate(zip(e.args, params), start=1):
            self.expect(arg, pt, scope, ctx, f"argument {k} of {e.func}()")
        return ret

    def quant(self, e: A.Quant, scope: set[str], ctx: str) -> Type:
        if ctx not in CONTRACTS:
            raise TypeCheckError(f"'{e.kind}' is only allowed in requires, ensures and invariant clauses", e.pos)
        v = e.var
        if v in self.params or v in self.all_locals or v in self.bound or v == RESULT:
            raise TypeCheckError(f"quantified variable '{v}' would shadow an existing name; pick another", e.pos)
        self.expect(e.lo, INT, scope, ctx, f"the lower bound of a {e.kind} range")
        self.expect(e.hi, INT, scope, ctx, f"the upper bound of a {e.kind} range")
        self.bound.add(v)
        try:
            self.expect(e.body, BOOL, scope, ctx, f"the body of a {e.kind}")
        finally:
            self.bound.discard(v)
        return BOOL

    def expect(self, e: A.Expr, want: Type, scope: set[str], ctx: str, what: str) -> None:
        got = self.expr(e, scope, ctx)
        if got != want:
            raise TypeCheckError(f"{what} must be {want}, got {got}", e.pos)

    def name(self, e: A.Name, scope: set[str], ctx: str) -> Type:
        n = e.ident
        if n in self.bound:
            return INT
        if n == RESULT:
            if ctx != "ensures":
                raise TypeCheckError("'result' can only be used in 'ensures' clauses", e.pos)
            return self.info.return_type
        if ctx in ("requires", "ensures", "decreases"):
            if n not in self.params:
                what = "unknown variable" if n not in self.all_locals else "local variable"
                extra = " and result" if ctx == "ensures" else ""
                raise TypeCheckError(f"'{ctx}' may only refer to parameters{extra}; '{n}' is a {what}", e.pos)
            return self.params[n]
        if n not in scope:
            if n in self.all_locals:
                raise TypeCheckError(f"variable '{n}' may be used before it is assigned", e.pos)
            raise TypeCheckError(f"undefined variable '{n}'", e.pos)
        return self.info.var_type(n)

    def cond(self, c: A.Expr, scope: set[str], ctx: str, what: str) -> None:
        self.expect(c, BOOL, scope, ctx, what)

    # ---- statements ------------------------------------------------------

    def block(self, stmts: list[A.Stmt], scope: set[str]) -> tuple[set[str], bool]:
        """Check a statement list. Returns (definitely-assigned names after it, always returns)."""
        returns = False
        for s in stmts:
            if returns:
                raise TypeCheckError("unreachable code after 'return'", s.pos)
            scope, returns = self.stmt(s, scope)
        return scope, returns

    def check_target(self, s: A.Assign | A.AssignIndex) -> None:
        if s.target in self.params:
            raise TypeCheckError(
                f"cannot assign to parameter '{s.target}' (parameters are immutable so that "
                "'ensures' refers to their input values)", s.pos)
        if s.target == RESULT:
            raise TypeCheckError("cannot assign to 'result'; use 'return'", s.pos)

    def stmt(self, s: A.Stmt, scope: set[str]) -> tuple[set[str], bool]:
        if isinstance(s, A.Assign):
            self.check_target(s)
            t = self.expr(s.value, scope, "body")
            prev = self.info.local_types.setdefault(s.target, t)
            if prev != t:
                raise TypeCheckError(f"cannot assign {t} to '{s.target}' of type {prev}", s.pos)
            return scope | {s.target}, False
        if isinstance(s, A.AssignIndex):
            self.check_target(s)
            t = self.name(A.Name(s.target, s.pos), scope, "body")
            if t != ARRAY:
                raise TypeCheckError(f"cannot index '{s.target}' of type {t}", s.pos)
            self.expect(s.index, INT, scope, "body", "an array index")
            self.expect(s.value, INT, scope, "body", "an array element")
            return scope, False
        if isinstance(s, A.Return):
            t = self.expr(s.value, scope, "body")
            if t != self.info.return_type:
                raise TypeCheckError(f"return type mismatch: expected {self.info.return_type}, got {t}", s.pos)
            return scope, True
        if isinstance(s, A.If):
            self.cond(s.cond, scope, "body", f"the '{s.keyword}' condition")
            s1, r1 = self.block(s.then_body, set(scope))
            s2, r2 = self.block(s.else_body, set(scope))
            if r1 and r2:
                return scope, True
            if r1:
                return s2, False
            if r2:
                return s1, False
            return s1 & s2, False
        if isinstance(s, A.While):
            for inv in s.invariants:
                self.cond(inv, scope, "invariant", "an invariant")
            self.cond(s.cond, scope, "body", "the 'while' condition")
            self.block(s.body, set(scope))
            # The body may run zero times, so it adds nothing to the definitely-assigned set.
            return scope, False
        raise TypeError(s)

    def check(self) -> FunctionInfo:
        for c in self.func.requires:
            self.cond(c, set(), "requires", "a 'requires' clause")
        for c in self.func.ensures:
            self.cond(c, set(), "ensures", "an 'ensures' clause")
        if self.func.decreases is not None:
            self.expect(self.func.decreases, INT, set(), "decreases", "a 'decreases' measure")
        _, returns = self.block(self.func.body, set(self.params))
        if not returns:
            raise TypeCheckError(f"function '{self.func.name}' may reach the end of its body without returning",
                                 self.func.pos)
        return self.info


def recursion_groups(infos: list[FunctionInfo]) -> None:
    """Fill in `recursive_group`: the functions on a call cycle through each function."""
    calls = {f.func.name: f.callees for f in infos}

    def reach(start: str) -> set[str]:
        seen: set[str] = set()
        todo = list(calls[start])
        while todo:
            g = todo.pop()
            if g not in seen:
                seen.add(g)
                todo.extend(calls[g])
        return seen

    reachable = {name: reach(name) for name in calls}
    for f in infos:
        name = f.func.name
        if name in reachable[name]:
            f.recursive_group = frozenset(g for g in reachable[name] if name in reachable[g])
            if f.func.decreases is None:
                raise TypeCheckError(
                    f"recursive function '{name}' needs a 'decreases' clause (termination is not inferred)",
                    f.func.pos)


def check_program(prog: A.Program) -> TypedProgram:
    seen: dict[str, Pos] = {}
    signatures: dict[str, Signature] = {}
    for f in prog.functions:
        if f.name in seen:
            raise TypeCheckError(f"function '{f.name}' is already defined at line {seen[f.name].line}", f.pos)
        if f.name in BUILTINS:
            raise TypeCheckError(f"'{f.name}' is a builtin function and cannot be redefined", f.pos)
        seen[f.name] = f.pos
        signatures[f.name] = (tuple(resolve_type(p.type) for p in f.params), resolve_type(f.return_type))
    infos = [FunctionChecker(f, signatures).check() for f in prog.functions]
    recursion_groups(infos)
    return TypedProgram(prog, infos)
